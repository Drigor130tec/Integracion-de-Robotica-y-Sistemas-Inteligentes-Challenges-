#!/usr/bin/env python3

import rospy
import math
import numpy as np
import message_filters
from std_msgs.msg import Float32, Header, String
from geometry_msgs.msg import Twist, Point
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from tf import transformations
from std_srvs.srv import SetBool, SetBoolResponse

class GoToPos:
    def __init__(self):
        # Inicializar el nodo
        self.local_goal: Point = None
        		#Points of the trajectory
        self.goals = [Point(x = 2.0, y = 0.0, z = 0.0),
                      Point(x = 2.0, y = 2.0, z = 0.0),
                      Point(x = 0.0, y = 2.0, z = 0.0),
                      Point(x = 0.0, y = 0.0, z = 0.0)]
        self.index = 0
        #Limit of coordinates
        self.n_goals = len(self.goals)
        #Function to create the NextPoint-Trajectory
        self.set_Trajectory(self.goals[self.index])
		
        # Parámetros
        self.current_pos = Point()
 
        self.kl = 0.001638
        self.kr = 0.0030171
        self.kp_ang = 0.3
        self.ki_ang = 0.016
        self.kp_dist = 0.3
        self.ki_dist = 0.015

        self.pose_theta = 0.0
        self.pose_x = 0.0
        self.pose_y = 0.0
        
        #Time meditions
        self.current_time = 0.0
        self.previous_time = 0.0
        
        self.wheel_base = 0.19
        self.wheel_radio = 0.05
        
        self.ang_error = 0.0
        self.dist_error = 0.0
        
        self.dist_offset = 0.0
        self.angle_offset = 0.0
        
        self.threshold_yaw = 0.05
        self.threshold_distance = 0.08
        
        self.error_int_ang = 0.0
        self.error_int_dist = 0.0
         
        self.yaw = 0
        self.state = 0
        self.wl = 0.0000000001
        self.wr = 0.0000000001
        self.activate = False
        self.msg_to_publish = Twist()
        self.time = rospy.Time.now()
        
        # Publicador y suscriptor
        self.pub = rospy.Publisher("/puzzlebot_1/base_controller/cmd_vel", Twist, queue_size=10)
        self.sub = rospy.Subscriber("/odom", Odometry, self.calc_pos_rpy)

        # Servicio
        wlsub = message_filters.Subscriber('/puzzlebot_1/wl', Float32)
        wrsub = message_filters.Subscriber('/puzzlebot_1/wr', Float32)
        ts = message_filters.ApproximateTimeSynchronizer([wlsub, wrsub], queue_size=10, slop=1.0/50, allow_headerless=True)
        ts.registerCallback(self.w_callback)
        self.srv = rospy.Service("/serv_go_to_pos", SetBool, self.go_to_pos_handler)
        self.rate = rospy.Rate(20)
        
    def wrap_to_pi(self, theta):
        result = np.fmod(theta + np.pi, 2 * np.pi)
        if isinstance(theta, np.ndarray):
            result[result < 0] += 2 * np.pi
        elif result < 0: 
            result += 2 * np.pi
        return result - np.pi

    def set_Trajectory(self, goal: Point):
        self.error_int_lin = 0.0
        self.error_int_ang = 0.0
        self.error_prev_lin = 0.0
        self.error_prev_ang = 0.0
        self.local_goal = goal       
         
    def go_to_pos_handler(self, req):
        self.activate = req.data
        res = SetBoolResponse()
        res.success = True
        res.message = "done"
        return res

    def w_callback(self, wl, wr):
        self.wl = wl.data
        self.wr = wr.data
    
    def done(self):
        self.msg_to_publish.linear.x = 0
        self.msg_to_publish.angular.z = 0
        self.pub.publish(self.msg_to_publish)
        rospy.loginfo("REACHED!")

    def go_straight_camera(self):
        self.dist_offset = math.sqrt(math.pow((self.local_goal.y - self.current_pos.y), 2) + math.pow((self.local_goal.x - self.current_pos.x), 2))
        desired_yaw = math.atan2(self.local_goal.y - self.current_pos.y, self.local_goal.x - self.current_pos.x)
        self.angle_offset = desired_yaw - self.yaw
        if self.angle_offset > math.pi:
            self.angle_offset = self.angle_offset - 2 * math.pi

    def reach_point(self):
        if self.index == self.n_goals-1:
            self.change_state(3)
        else:    
            self.index +=1 #Next Point
            self.index = self.index % self.n_goals
            self.set_Trajectory(self.goals[self.index])
            
            self.change_state(0)        
            
    def go_straight_encoders(self):
        self.angle_correction()
        
        self.pose_x += self.dt * self.wheel_radio * ((self.wr + self.wl) / 2) * np.cos(self.pose_theta)
        self.pose_y += self.dt * self.wheel_radio * ((self.wr + self.wl) / 2) * np.sin(self.pose_theta)
        
        self.dist_error = np.sqrt(np.square(self.local_goal.x - self.pose_x) + np.square(self.local_goal.y - self.pose_y))

    def change_state(self, n):
        self.state = n
        #rospy.loginfo("Changed to state [{}]".format(n))
        
    def angle_correction(self):
        #error with odom
        desired_yaw = math.atan2(self.local_goal.y - self.current_pos.y, self.local_goal.x - self.current_pos.x)
        self.angle_offset = self.wrap_to_pi(desired_yaw - self.yaw)
        
        #error with encoders
        self.pose_theta = self.wrap_to_pi(self.pose_theta + self.dt * self.wheel_radio * ((self.wr - self.wl) / self.wheel_base))
        error_x = self.local_goal.x - self.pose_x 
        error_y = self.local_goal.y - self.pose_y
        ref_ang = np.arctan2(error_y, error_x)
        self.ang_error = self.wrap_to_pi(ref_ang - self.pose_theta)         

        #rospy.loginfo(f"angular errors: ({self.ang_error} , {self.angle_offset})")
 
        self.error_int_ang += self.ang_error * self.dt
        ang_control = (self.kp_ang * self.ang_error) + (self.ki_ang * self.error_int_ang) 
        #rospy.loginfo(f"angle: {ang_control} ") 
        
        if math.fabs(self.ang_error) > 0.01:
            self.msg_to_publish.angular.z = ang_control if self.ang_error > 0 else -ang_control
            self.msg_to_publish.linear.x = 0
            self.pub.publish(self.msg_to_publish)
        else:
            #rospy.loginfo("Angle offset is: {}".format(self.ang_error))
            self.change_state(1)

        
    def distance_correction(self):
        self.go_straight_camera()
        self.go_straight_encoders()
        self.error_int_dist += self.dist_error * self.dt
        dist_control = (self.kp_dist * self.dist_error) + (self.ki_dist * self.error_int_dist)
        #rospy.loginfo(f"angle: {dist_control} ") 
        if self.dist_error > self.threshold_distance:
            self.msg_to_publish.linear.x = dist_control
            self.msg_to_publish.angular.z = 0
            self.pub.publish(self.msg_to_publish)
        else:
            #rospy.loginfo("Distance offset is: {}".format(self.dist_offset))
            self.change_state(2)
        
        if math.fabs(self.ang_error) > 0.01:
            #rospy.loginfo("Angle offset is: {}".format(self.angle_offset))
            self.change_state(0)

    def calc_pos_rpy(self, msg):
        self.current_pos = msg.pose.pose.position
        quaternion = [
            msg.pose.pose.orientation.x,
            msg.pose.pose.orientation.y,
            msg.pose.pose.orientation.z,
            msg.pose.pose.orientation.w
        ]
        euler = transformations.euler_from_quaternion(quaternion)
        self.yaw = euler[2]

    def run(self):
        while not rospy.is_shutdown():
            self.current_time = rospy.get_time()
            self.dt = (self.current_time - self.previous_time)
            self.previous_time = self.current_time
            print_info = "%3f | %3f | %3f | %3f " %(self.dist_error,self.dist_offset,self.ang_error,self.angle_offset)
            rospy.loginfo(print_info)
            if self.state == 0:
                self.angle_correction()            
            elif self.state == 1:
                self.distance_correction()
            elif self.state == 2:
                self.reach_point()
            elif self.state == 3:
                self.done()
            else:
                rospy.logerr("Unknown State")
            self.rate.sleep()

if __name__ == '__main__':
    rospy.init_node("go_to_pos")
    node = GoToPos()
    node.run()
