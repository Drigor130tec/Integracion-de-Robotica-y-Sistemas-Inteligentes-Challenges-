#!/usr/bin/env python

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

# Definimos el tipo de ArUCo tag a detectar
arUCo_type = "DICT_4X4_250"

# Definimos el diccionario de nombres de los ArUCo tags soportados por OpenCV
ARUCO_DICT = {
    "DICT_4X4_50": cv2.aruco.DICT_4X4_50,
    "DICT_4X4_100": cv2.aruco.DICT_4X4_100,
    "DICT_4X4_250": cv2.aruco.DICT_4X4_250,
    "DICT_4X4_1000": cv2.aruco.DICT_4X4_1000,
    "DICT_ARUCO_ORIGINAL": cv2.aruco.DICT_ARUCO_ORIGINAL,
}

# Verificamos que el ArUCo tag especificado exista y sea soportado por OpenCV
if ARUCO_DICT.get(arUCo_type, None) is None:
    rospy.loginfo("ArUCo tag '{}' no es soportado".format(arUCo_type))
    exit(0)

# Cargamos el diccionario de ArUCo
arucoDict = cv2.aruco.getPredefinedDictionary(ARUCO_DICT[arUCo_type])
arucoParams = cv2.aruco.DetectorParameters_create()

# Definimos los parámetros de la cámara (obtenidos de la calibración de la cámara)
# Esto es solo un ejemplo, necesitas usar los valores obtenidos de tu calibración
camera_matrix = np.array([[1000, 0, 640], [0, 1000, 360], [0, 0, 1]], dtype=np.float32)
dist_coeffs = np.zeros((5, 1), dtype=np.float32)

class ArucoDetector:
    def __init__(self):
        self.bridge = CvBridge()
        self.image_sub = rospy.Subscriber("/puzzlebot_1/camera/image_raw", Image, self.callback)
        rospy.loginfo("Aruco Detector Node Initialized")

    def callback(self, data):
        try:
            frame = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            rospy.logerr("CvBridge Error: {0}".format(e))

        # Detectamos marcadores ArUCo en el frame de entrada
        corners, ids, rejected = cv2.aruco.detectMarkers(frame, arucoDict, parameters=arucoParams)

        # Verificamos que *al menos* un marcador ArUCo haya sido detectado
        if ids is not None and len(corners) > 0:
            # Aplanamos la lista de IDs de ArUCo
            ids = ids.flatten()

            # Estimamos la pose de cada marcador detectado
            rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(corners, 0.05, camera_matrix, dist_coeffs)

            # Loop sobre las esquinas detectadas de ArUCo
            for i in range(len(ids)):
                markerID = ids[i]
                rvec = rvecs[i]
                tvec = tvecs[i]

                # Imprime el ID del marcador detectado
                rospy.loginfo(f"Marker ID detected: {markerID}")

                # Extraemos las esquinas del marcador (siempre se devuelven
                # en el orden superior-izquierda, superior-derecha, inferior-derecha e inferior-izquierda)
                markerCorner = corners[i].reshape((4, 2))
                (topLeft, topRight, bottomRight, bottomLeft) = markerCorner

                # Convertimos cada par de coordenadas (x, y) a enteros
                topRight = (int(topRight[0]), int(topRight[1]))
                bottomRight = (int(bottomRight[0]), int(bottomRight[1]))
                bottomLeft = (int(bottomLeft[0]), int(bottomLeft[1]))
                topLeft = (int(topLeft[0]), int(topLeft[1]))

                # Dibujamos el cuadro delimitador de la detección de ArUCo
                cv2.line(frame, topLeft, topRight, (0, 255, 0), 2)
                cv2.line(frame, topRight, bottomRight, (0, 255, 0), 2)
                cv2.line(frame, bottomRight, bottomLeft, (0, 255, 0), 2)
                cv2.line(frame, bottomLeft, topLeft, (0, 255, 0), 2)

                # Calculamos y dibujamos las coordenadas del centro (x, y) del marcador ArUCo
                cX = int((topLeft[0] + bottomRight[0]) / 2.0)
                cY = int((topLeft[1] + bottomRight[1]) / 2.0)
                cv2.circle(frame, (cX, cY), 4, (0, 0, 255), -1)

                # Dibujamos el ID del marcador ArUCo en el frame
                cv2.putText(frame, str(markerID),
                            (topLeft[0], topLeft[1] - 15),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.5, (0, 255, 0), 2)

                # Extraemos la posición y la orientación
                rvec_str = "Rvec: [{:.2f}, {:.2f}, {:.2f}]".format(rvec[0][0], rvec[0][1], rvec[0][2])
                tvec_str = "Tvec: [{:.2f}, {:.2f}, {:.2f}]".format(tvec[0][0], tvec[0][1], tvec[0][2])

                print("ID: {}".format(markerID))
                print(rvec_str)
                print(tvec_str)
                # Dibujamos la posición y la orientación en el frame
                
                cv2.putText(frame, rvec_str, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                cv2.putText(frame, tvec_str, (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # Mostramos el frame de salida
        cv2.imshow("Frame", frame)
        cv2.waitKey(3)

def main():
    rospy.init_node('aruco_detector_node', anonymous=True)
    ad = ArucoDetector()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        rospy.loginfo("Shutting down")

    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()

