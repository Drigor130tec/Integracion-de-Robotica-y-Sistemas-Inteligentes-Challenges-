#!/usr/bin/env python3
import rospy
import math
from geometry_msgs.msg import Twist, PoseStamped
from std_msgs.msg import Float32

class Real_Sim_Robot:
    def __init__(self):
        #Physical attributes of the Robot 
        self.wheel_radio = 0.05
        self.wheel_base = 0.19

        #Publishers and Subscribers
        self.cmd_sub = rospy.Subscriber('/cmd_vel', Twist, self.cmd_vel_callback)
        self.pose_pub = rospy.Publisher('/pose', PoseStamped, queue_size=10)
        self.wl_pub = rospy.Publisher('/wl', Float32, queue_size=10)
        self.wr_pub = rospy.Publisher('/wr', Float32, queue_size=10)

        # Init Robot pose attributes
        self.robot_pose = PoseStamped()
        self.robot_pose.pose.position.x = 0.0
        self.robot_pose.pose.position.y = 0.0
        self.robot_pose.pose.orientation.z = 0.0
        self.robot_pose.pose.orientation.w = 1.0

        #Init Puzzlebot wheel velocities
        self.wl = rospy.get_param("wl", 0.0)
        self.wr = rospy.get_param("wr", 0.0)

        self.time = rospy.Time.now()

    def cmd_vel_callback(self, msg):
        # Calcular las velocidades angulares de las ruedas izquierda y derecha
        linear_vel = msg.linear.x
        angular_vel = msg.angular.z

        self.wl = (2.0 * linear_vel - angular_vel * self.wheel_base) / (2*self.wheel_radio)
        self.wr = (2.0 * linear_vel + angular_vel * self.wheel_base) / (2*self.wheel_radio)

        self.update_Pose(self.get_dt())

    def update_Pose(self, dt):
        v = self.wheel_radio * (self.wl + self.wr) / 2.0
        w = self.wheel_radio * (self.wr - self.wl) / self.wheel_base

        self.robot_pose.pose.position.x += v * math.cos(self.robot_pose.pose.orientation.z) * dt
        self.robot_pose.pose.position.y += v * math.sin(self.robot_pose.pose.orientation.z) * dt
        self.robot_pose.pose.orientation.z += w * dt

    def publish_robot_state(self):
        self.pose_pub.publish(self.robot_pose)
        self.wl_pub.publish(self.wl)
        self.wr_pub.publish(self.wr)

    def get_dt(self):
        current_time = rospy.Time.now()
        dt = (current_time - self.time).to_sec()
        self.time = current_time
        return dt

if __name__ == '__main__':
    rospy.init_node("Real_Sim_Robot")
    RSR = Real_Sim_Robot()
    loop_rate = rospy.Rate(100)  # 10 Hz
  
    try:
        while not rospy.is_shutdown():
            # Publish Pose and Wheel Velocities
            RSR.publish_robot_state()
            loop_rate.sleep()
            
    except rospy.ROSInterruptException:
        pass
        

