#!/usr/bin/env python3
import rospy
import math
import numpy as np
from geometry_msgs.msg import Twist, Pose, Point, Quaternion
from std_msgs.msg import Float32 , String

class Real_Sim_Robot:
    def __init__(self):
        self.isListening  = False
        #Physical attributes of the Robot 
        self.wheel_radio = 0.05
        self.wheel_base = 0.19

        #Publishers and Subscribers
        self.cmd_sub = rospy.Subscriber('/cmd_vel_RVIZ', Twist, self.cmd_vel_callback)
        self.wl_pub = rospy.Publisher('/wl_RVIZ', Float32, queue_size=10)
        self.wr_pub = rospy.Publisher('/wr_RVIZ', Float32, queue_size=10)

        self.robot_pose: Pose = Pose(position = Point(x = 0.0, y = 0.0, z = 0.0), orientation = Quaternion(x = 0.0, y = 0.0, z = 0.0, w = 1.0))

        #Init Puzzlebot wheel velocities
        self.v = rospy.get_param("v", 0.0000)
        self.w = rospy.get_param("w", 0.0000)
        
        self.wl = rospy.get_param("wr", 0.0000)
        self.wr = rospy.get_param("wl", 0.0000)
        
        #matriz covarianza
        self.kl = 0.01378544028
        self.kr = 0.01378544028
        self.covarianza =np.array([[0,0,0],[0,0,0],[0,0,0]])
        
        self.time = rospy.Time.now()
        #rospy.Timer(rospy.Duration(1.0/50), self.update_Pose)

    def get_dt(self):
        current_time = rospy.Time.now()
        dt = (current_time - self.time).to_sec()
        self.time = current_time
        return dt
    
    def gradient(self, theta, wr, wl):
        """ Jacobian matrix"""
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        r = self.wheel_radio
        l = self.wheel_base

        #Jacobian Declaration
        J_notLin = np.array([[r * cos_theta / 2.0, r * cos_theta / 2.0], 
                            [r * sin_theta / 2.0, r * sin_theta / 2.0], 
                            [r / (l), -r / (l)]])
        
        J_Lin = np.array([[-r * sin_theta / 2.0, -r * sin_theta / 2.0], 
                           [r * cos_theta / 2.0, r * cos_theta / 2.0], 
                           [r / (l), -r / (l)]])
        #Not-Linealized Model
        return np.dot(J_notLin, np.array([wr, wl]))
        #Linealized Model
        #return np.dot(J_Lin, np.array([wr, wl]))
    
    def cmd_vel_callback(self, msg):
        if self.isListening:
            self.v = msg.linear.x
            self.w = msg.angular.z
            self.isListening = False

    def wrap_to_pi(self, theta):
        result = np.fmod(theta + np.pi, 2 * np.pi)

        if isinstance(theta, np.ndarray):
            result[result < 0] += 2 * np.pi
        elif result < 0: 
            result += 2 * np.pi
        return result - np.pi
    
    def rk_integration(self, dt, state, wr, wl):
        # Compute RK4 updates
        k1 = self.gradient(state[2], wr, wl)
        k2 = self.gradient(state[2] + dt*k1[2]/2.0, wr, wl)
        k3 = self.gradient(state[2] + dt*k2[2]/2.0, wr, wl)
        k4 = self.gradient(state[2] + dt*k3[2], wr, wl)

        # Update position and orientation using RK4
        return dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6.0

    def update_Pose(self):  
        dt = self.get_dt()

        r = self.wheel_radio
        l = self.wheel_base

        # Control to wheel velocities matrix
        wheel_matrix = np.linalg.inv(np.array([[r/2.0,  r/2.0], 
                                               [r/(l), -r/(l)]]))

        wr, wl = np.dot(wheel_matrix, np.array([self.v, self.w]))

        pos = np.array([self.robot_pose.position.x, self.robot_pose.position.y, self.robot_pose.orientation.z])
        pos = pos + self.rk_integration(dt, pos, wr, wl)
        
        self.robot_pose = Pose(position = Point(x = pos[0], y = pos[1], z = 0.0), 
                               orientation = Quaternion(x = 0.0, y = 0.0, z = self.wrap_to_pi(pos[2]), w = 1.0))

        self.wl_pub.publish(wl)
        self.wr_pub.publish(wr)
        self.wr = wr
        self.wl = wl
        self.isListening = True

        
if __name__ == '__main__':
    rospy.init_node("Real_Sim_Robot")
    RSR = Real_Sim_Robot()
    loop_rate = rospy.Rate(100)  # 10 Hz
  
    try:
        while not rospy.is_shutdown():
            # Publish Pose and Wheel Velocities
            RSR.update_Pose()
            loop_rate.sleep()
            
    except rospy.ROSInterruptException:
        pass