#!/usr/bin/env python3
import rospy
import message_filters
import numpy as np 
from std_msgs.msg import Float32, Header
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Vector3, Point, Quaternion, Pose, Twist, PoseWithCovariance, TwistWithCovariance

class Localisation_RVIZ:
    def __init__(self):
        #Wheel Attributes / Physical Robot Attributes
        self.wheel_radio = 0.05
        self.wheel_base = 0.19

        #Pose parameters / Dummy Init
        self.dt = 0.0
        #Init Puzzlebot wheel velocities
        self.v = rospy.get_param("v", 0.0)
        self.w = rospy.get_param("w", 0.0)
        
        self.wl = 0.0000001     #Data to avoid division to 0
        self.wr = 0.0000001
 
        self.kl = 0.01638
        self.kr = 0.0030171
        
        self.SigmaK =np.array([[0,0,0],[0,0,0],[0,0,0]])
        self.mu = np.array([[0.0], [0.0], [0.0]])
        self.m = np.array([[0.0],[0.0]])
        self.z_k = np.array([[0.0],[0.0]]) 

        self.landmark_pos = {
            0: Point(1.5, 1.0, 0.0),
            1: Point(1.0, 0.5, 0.0),
            2: Point(0.0, 2.0, 0.0)
        }                              
                                      
        self.decodematrix = np.array([[self.wheel_radio / 2.0,                self.wheel_radio / 2.0], 
                                      [self.wheel_radio / self.wheel_base,   - self.wheel_radio / self.wheel_base]])
 
        self.odom_pub = rospy.Publisher("/odom_gazebo", Odometry, queue_size=10)

        #Declaration of Publishers and Subscribers of the Node
        wlsub = message_filters.Subscriber('/puzzlebot_1/wl', Float32)
        wrsub = message_filters.Subscriber('/puzzlebot_1/wr', Float32)

        # Synchronizer
        ts = message_filters.ApproximateTimeSynchronizer([wlsub, wrsub], queue_size=10, slop=0.05, allow_headerless=True)
        ts.registerCallback(self.w_callback)
        
        self.aruco_sub = rospy.Subscriber('/aruco_info_gazebo', Point, self.aruco_Callback)
        self.aruco_detected = False
        
        self.listening = True
        rospy.Timer(rospy.Duration(1.0/50), self.odom_publish) 
        #Declaration of the delta Time
        self.time = rospy.Time.now()

    def system_gradient(self, theta, v, w):
        return np.array([v * np.cos(theta), v * np.sin(theta), w])
    
    #Runge Kutta Method for Differential Ecuations
    def rk4_delta(self, dt, theta, v, w):
        k1 = self.system_gradient(theta, v, w)
        k2 = self.system_gradient(theta + dt*k1[2]/2.0, v, w)
        k3 = self.system_gradient(theta + dt*k2[2]/2.0, v, w)
        k4 = self.system_gradient(theta + dt*k3[2], v, w)
        return dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6.0

    def elipse_covarianza(self, dt):
    #Estimate position of the robot (2)
    #Increment position (States) using Runge Kutta Method
        deltaX = self.rk4_delta(dt, self.mu[2,0], self.v, self.w)
        mu_k_est = np.array([[self.mu[0,0] + deltaX[0]], 
                            [self.mu[1,0] + deltaX[1]], 
                            [self.wrap_to_pi(self.mu[2,0] + deltaX[2])]]) 
        #rospy.loginfo(f"Where am I? : {self.mu}")
    #Linearized model. Hk (3)
        Hk = np.array([[1, 0, -self.v * np.sin(self.mu[2,0]) * dt],
                       [0, 1, self.v * np.cos(self.mu[2,0]) * dt],
                       [0, 0, 1]]) 
        
    #Qk obtention = nabla_k * sigma_delta_k * nabla_k^T
        sigma_delta_k = np.array([[self.kr*abs(self.wr), 0],
                                [0, self.kl*abs(self.wl)]])  
                                
        nabla_k = (1/2.0) * self.wheel_radio * dt * np.array([[np.cos(self.mu[2,0]), np.cos(self.mu[2,0])],
                                                    [np.sin(self.mu[2,0]), np.sin(self.mu[2,0])],
                                                    [2/self.wheel_base, -2/self.wheel_base]])
        Q_k = nabla_k @ sigma_delta_k @ nabla_k.T

    #Uncertainty propagation. Sigma estimation (4)
        sigma_est = Hk @ self.SigmaK @ Hk.T + Q_k
        
        if self.aruco_detected:
    #Error to landmark (5)
            dx = self.m[0,0] - mu_k_est[0,0]
            dy = self.m[1,0] - mu_k_est[1,0]
            p = dx**2 + dy**2
    #Measuremnts with observation model (6)
            z_est = np.array([[np.sqrt(p)], 
                             [np.arctan2(dy, dx) - mu_k_est[2,0]]])

            self.z_k[1,0] =  z_est[1,0]*1.002
        #Linearise the observation model (7)
            Gk = np.array([[-dx / np.sqrt(p), -dy / np.sqrt(p), 0],
                            [dy / np.sqrt(p), -dx / np.sqrt(p), -1]])
            #Rk obtention
            R_k = np.array([[0.1, 0], 
                            [0, 0.02]])
        #Uncertainty propagation. Zk estimation (8)
            Zk = Gk @ sigma_est @ Gk.T + R_k
        #Kalman Gain (9)
            Kk = sigma_est @ Gk.T @ np.linalg.pinv(Zk)
            
        #Robot position with observation model and final covariance matrix (10 - 11)
            incremento = Kk @ (self.z_k - z_est)
            rospy.loginfo("Se detecto un ARUco")
            #rospy.loginfo(f"Diferencia en X: {dx}")
            #rospy.loginfo(f"Diferencia en Y: {dy}")
            #rospy.loginfo(f"Landmark ideal: {self.m}")
            #rospy.loginfo(f"Landmark real: {self.z_k}")
            rospy.loginfo(f"Posicion: {z_est}")
            #rospy.loginfo(f"Kalman: {Kk}")
            #rospy.loginfo(f"Diferencia: {self.z_k - z_est}")
            #rospy.loginfo(f"incremento: {incremento}")
            self.mu = mu_k_est + Kk @ (self.z_k - z_est)
            #rospy.loginfo(f"new values: {self.mu}")
            #Final values covariance Matrix
            self.SigmaK = (np.eye(3) - Kk @ Gk) @ sigma_est

        #Robot position wihout Aruco correction - No detection
        else:
            self.mu = mu_k_est
            self.SigmaK = sigma_est

        self.listening = True
        
    def set_odom_msg(self):
        #rospy.loginfo(f"X odom: {self.mu[0,0]}")
        #rospy.loginfo(f"Y odom: {self.mu[1,0]}")
        #rospy.loginfo(f"T odom: {self.mu[2,0]}")
        self.odom_pub.publish(Odometry(
            header = Header(frame_id = 'world', stamp = rospy.Time.now()),
            child_frame_id = '',
            # Pose in inertial frame (world_frame)
            pose = PoseWithCovariance(
                pose = Pose(
                    position = Point(x = self.mu[0,0], y = self.mu[1,0], z = 0.0),
                    orientation = Quaternion(x = 0.0, y = 0.0, z = self.wrap_to_pi(self.mu[2,0]), w = 1.0)),
                
                covariance = np.array([self.SigmaK[0,0], self.SigmaK[0,1],0.0, 0.0, 0.0, self.SigmaK[0,2],
                                       self.SigmaK[1,0], self.SigmaK[1,1],0.0, 0.0, 0.0, self.SigmaK[1,2],
                                       0.0,0.0,0.0,0.0,0.0,0.0,
                                       0.0,0.0,0.0,0.0,0.0,0.0,
                                       0.0,0.0,0.0,0.0,0.0,0.0,
                                       self.SigmaK[2,0], self.SigmaK[2,1],0.0, 0.0, 0.0, self.SigmaK[0,0]])
            ),
            # Twist in child frame (puzzlebot)
            twist = TwistWithCovariance(
                twist = Twist(
                    linear = Vector3(x = (self.wl * self.wheel_radio), y = (self.wr * self.wheel_radio), z = 0.0),
                    angular = Vector3(x = self.wl, y = self.wr, z = 0.0)
                ),
                covariance = None)))

#SIDE FUNCTIONS
    def w_callback(self, wl, wr):
        if self.listening:
            self.v, self.w = np.dot(self.decodematrix, np.array([self.wr, self.wl]).T).flatten()
            self.wl = wl.data
            self.wr = wr.data

    def get_dt(self):
        current_time = rospy.Time.now()
        dt = (current_time - self.time).to_sec()
        self.time = current_time
        return dt
    
    def aruco_Callback(self, msg):
        landmark_x = msg.x
        landmark_y = msg.y
        index = msg.z

        if index in self.landmark_pos:
            self.aruco_detected = True
            self.z_k[0,0] = landmark_x
            self.z_k[1,0] = landmark_y
            expected_landmark = self.landmark_pos[index]
            self.m[0,0] = expected_landmark.x
            self.m[1,0] = expected_landmark.y
        else:
            self.aruco_detected = False 
  
    def wrap_to_pi(self, theta):
        result = np.fmod(theta + np.pi, 2 * np.pi)
        if isinstance(theta, np.ndarray):
            result[result < 0] += 2 * np.pi
        elif result < 0: 
            result += 2 * np.pi
        return result - np.pi

    
    def odom_publish(self, _):
        dt = self.get_dt()
        self.dt = dt
        # Integration
        self.elipse_covarianza(dt)
        self.set_odom_msg()
        self.listening = True

if __name__=='__main__':
    #Initialise and Setup node
    rospy.init_node("Localisation_rviz")
    L = Localisation_RVIZ()
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        pass 
