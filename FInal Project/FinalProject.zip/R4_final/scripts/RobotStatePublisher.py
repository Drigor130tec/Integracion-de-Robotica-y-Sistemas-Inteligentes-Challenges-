#!/usr/bin/env python3
import rospy
import tf2_ros
import numpy as np
from std_msgs.msg import Header
from geometry_msgs.msg import TransformStamped, Quaternion, Vector3, Transform, Point, Pose, Twist, PoseWithCovariance, TwistWithCovariance
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState


class DualRobotStatePublisher: 
    def __init__(self):
        self.is_RVIZ_ok = False
        self.is_RVIZ2_ok = False
        #Robot's Position
        self.time = rospy.Time.now()
        self.covariance_matrix = None 
        self.joint_names = rospy.get_param('~joint_names', ['leftWheel', 'rightWheel'])
        self.ideal_joints_positions = [0.0]*len(self.joint_names)
        self.broadcaster = tf2_ros.TransformBroadcaster()

        self.joint_names_Puzzlebot = rospy.get_param('~joint_names2', ['leftWheel2', 'rightWheel2'])
        self.real_joints_positions = [0.0]*len(self.joint_names_Puzzlebot)
        self.broadcasterPuzzlebot = tf2_ros.TransformBroadcaster()
        self.set_odom_frame()

        #Declaration of Odom message (Ready to Publish) both Robots
        self.ideal_odom_msg = Odometry(
            header = Header(frame_id = 'odom', stamp = rospy.Time.now()), 
            child_frame_id = '',
            pose = PoseWithCovariance(
                pose = Pose(
                    position = Point(x = 0.0, y = 0.0, z = 0.0),
                    orientation = Quaternion(x = 0.0, y = 0.0, z = self.wrap_to_pi(0.0), w = 1.0)),
                covariance = None
            ),
            # Twist in child frame (puzzlebot)
            twist = TwistWithCovariance(
                twist = Twist(
                    linear = Vector3(x = 0.0, y = 0.0, z = 0.0),
                    angular = Vector3(x = 0.0, y = 0.0, z = 0.0)
                ),
                covariance = None
            )
        )
        self.real_odom_msg = Odometry(
            header = Header(frame_id = 'world', stamp = rospy.Time.now()),
            child_frame_id = '',
            pose = PoseWithCovariance(
                pose = Pose(
                    position = Point(x = 0.0, y = 0.0, z = 0.0),
                    orientation = Quaternion(x = 0.0, y = 0.0, z = self.wrap_to_pi(0.0), w = 1.0)),
                covariance = None
            ),
            # Twist in child frame (puzzlebot)
            twist = TwistWithCovariance(
                twist = Twist(
                    linear = Vector3(x = 0.0, y = 0.0, z = 0.0),
                    angular = Vector3(x = 0.0, y = 0.0, z = 0.0)
                ),
                covariance = None
            )
        )

        #Publisher and Subscriber
        self.ideal_odom_sub = rospy.Subscriber('/odom_rviz', Odometry, self.ideal_odom_callback)   
        self.real_odom_sub = rospy.Subscriber('/odom_gazebo', Odometry, self.real_odom_callback)     

        self.ideal_joint_pub = rospy.Publisher("/robot1/joint_states", JointState, queue_size=10)
        self.real_joint_pub = rospy.Publisher("/robot2/joint_states", JointState, queue_size=10)

        rospy.Timer(rospy.Duration(1.0/50), self.talk_to_rviz)

    def talk_to_rviz(self, _):
        self.publish_joints()
        self.is_RVIZ_ok = True
        self.is_RVIZ2_ok = True

    def publish_joints(self,):
        header = Header(frame_id = '/robot1/base_link', stamp = rospy.Time.now())
        header2 = Header(frame_id = '/robot2/base_link2', stamp = rospy.Time.now())

        robot_position_ideal = self.ideal_odom_msg.pose.pose.position
        robot_orientation_ideal = self.ideal_odom_msg.pose.pose.orientation.z

        robot_position_real = self.real_odom_msg.pose.pose.position
        robot_orientation_real = self.real_odom_msg.pose.pose.orientation.z
        
        self.ideal_broadcast_transform('/robot1/base_link', robot_position_ideal, robot_orientation_ideal)  
        self.real_broadcast_transform('/robot2/base_link2', robot_position_real, robot_orientation_real)  
        
        #Position and Velocities of each Joint
        ideal_joints_velocities = np.array([self.ideal_odom_msg.twist.twist.angular.x, 
                                            self.ideal_odom_msg.twist.twist.angular.y])
        
        real_joints_velocities = np.array([self.real_odom_msg.twist.twist.angular.x, 
                                           self.real_odom_msg.twist.twist.angular.y])
        
        self.ideal_joints_positions = self.wrap_to_pi(self.ideal_joints_positions + self.integrate_velocity(ideal_joints_velocities))
        self.real_joints_positions = self.wrap_to_pi(self.real_joints_positions + self.integrate_velocity(real_joints_velocities))
        
        self.ideal_joint_pub.publish(JointState(header=header, 
                                        position=self.ideal_joints_positions, 
                                        velocity=ideal_joints_velocities, 
                                        name=self.joint_names, 
                                        effort=[0.0, 0.0, 0.0]))
        
        self.real_joint_pub.publish(JointState(header=header2, 
                                            position=self.real_joints_positions, 
                                            velocity=real_joints_velocities, 
                                            name=self.joint_names_Puzzlebot, 
                                            effort=[0.0, 0.0, 0.0]))
    def ideal_odom_callback(self, msg):
        if self.is_RVIZ_ok:
            self.ideal_odom_msg = msg
            self.is_RVIZ_ok = False

    def real_odom_callback(self, msg):
        if self.is_RVIZ2_ok:
            self.real_odom_msg = msg
            self.is_RVIZ2_ok = False

    def set_odom_frame(self):
        t = TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "odom"
        t.child_frame_id = "/robot1/base_link"

        t.transform = Transform(
            translation = Vector3(0.0, 0.0, 0.0),
            rotation = Quaternion(0, 0, 0, 1) 
        )

        t2 = TransformStamped()
        t2.header.stamp = rospy.Time.now()
        t2.header.frame_id = "world"
        t2.child_frame_id = "/robot2/base_link2"

        t2.transform = Transform(
            translation = Vector3(0.0, 0.0, 0.0),
            rotation = Quaternion(0, 0, 0, 1) 
        )
        self.broadcaster.sendTransform(t)
        self.broadcaster.sendTransform(t2)

    def ideal_broadcast_transform(self, child_frame, position, orientation):
        t = TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "odom"
        t.child_frame_id = child_frame

        t.transform = Transform(
            translation = Vector3(x = position.x,
                                  y = position.y,
                                  z = position.z),
            rotation = Quaternion(*self.quaternion_from_z_rotation(orientation)) 
        )
        self.broadcaster.sendTransform(t)

    def real_broadcast_transform(self, child_frame, position, orientation):
        t = TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "world"
        t.child_frame_id = child_frame

        t.transform = Transform(
            translation = Vector3(x = position.x,
                                  y = position.y,
                                  z = position.z),
            rotation = Quaternion(*self.quaternion_from_z_rotation(orientation)) 
        )
        self.broadcaster.sendTransform(t)

    def quaternion_from_z_rotation(self, yaw):
        w = np.cos(yaw / 2)
        z = np.sin(yaw / 2)
        return (0.0, 0.0, z, w)
    
    def wrap_to_pi(self, theta):
        result = np.fmod(theta + np.pi, 2 * np.pi)

        if isinstance(theta, np.ndarray):
            result[result < 0] += 2 * np.pi
        elif result < 0: 
            result += 2 * np.pi
        return result - np.pi
    
    def integrate_velocity(self, wdot):
        return wdot * self.get_dt()
    
    def get_dt(self):
        current_time = rospy.Time.now()
        dt = (current_time - self.time).to_sec()
        self.time = current_time
        return dt

if __name__ == '__main__':
    rospy.init_node("DualRobotStatePublisher")
    RSP = DualRobotStatePublisher()

    loop_rate = rospy.Rate(100)  # 10 Hz
  
    try:
        rospy.spin()
            
    except rospy.ROSInterruptException:
        pass    