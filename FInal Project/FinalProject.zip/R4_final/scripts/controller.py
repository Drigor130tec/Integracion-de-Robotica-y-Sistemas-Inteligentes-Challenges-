#!/usr/bin/env python3
import rospy
import math
import numpy as np
from geometry_msgs.msg import Twist, Point
from nav_msgs.msg import Odometry
class GoToPos:
    def __init__(self):
        # Inicializar el nodo
        self.goals = [Point(x = 2.0, y = 0.0, z = 0.0),
                      Point(x = 2.0, y = 1.5, z = 0.0),
                      Point(x = 1.5, y = -0.75, z = 0.0),
                      Point(x = -1.0, y = 1.5, z = 0.0),
                      Point(x = 1.0, y = 1.0, z = 0.0),
                      Point(x = 0.0, y = 0.0, z = 0.0)]
        self.index_R = 0
        self.index_G = 0
        self.index_P = 0
        #Limit of coordinates
        self.n_goals = len(self.goals)
        self.local_goal_R = self.goals[0]
        self.local_goal_G = self.goals[0]
        self.local_goal_P = self.goals[0]
		
        # Parámetros
        self.current_pos = Point()
        self.current_pos_gazebo = Point()
        self.current_pos_puzzlebot = Point()
        
        #Controller constants
        self.kp_ang = 0.2
        self.ki_ang = 0.04
        self.kd_ang = 0.03    
        self.kp_dist = 0.3
        self.ki_dist = 0.025
        self.kd_dist = 0.05
        #Time meditions
        self.current_time = 0.0
        self.previous_time = 0.0
        
        self.wheel_base = 0.19
        self.wheel_radio = 0.05
        
        self.ang_error = 0.0
        self.dist_error = 0.0
        self.error_prev_dist = 0.0
        self.error_prev_ang = 0.0       
        self.error_int_ang = 0.0
        self.error_int_dist = 0.0
        
        self.ang_error_rviz = 0.0
        self.dist_error_rviz = 0.0
        self.error_prev_dist_rviz = 0.0
        self.error_prev_ang_rviz = 0.0       
        self.error_int_ang_rviz = 0.0
        self.error_int_dist_rviz = 0.0
        
        self.ang_error_puzzlebot = 0.0
        self.dist_error_puzzlebot = 0.0
        self.error_prev_dist_puzzlebot = 0.0
        self.error_prev_ang_puzzlebot = 0.0       
        self.error_int_ang_puzzlebot = 0.0
        self.error_int_dist_puzzlebot = 0.0
        
        self.yaw_rviz = 0
        self.yaw_gazebo = 0
        self.yaw_puzzlebot = 0
        
        self.threshold_distance = 0.04
        self.state_R = 0
        self.state_G = 0
        self.state_P = 0

        self.min_angular_speed = 0.12
        self.min_linear_speed = 0.18

        self.switch_stateG = {
            0: self.correction_gazebo,
            1: self.reach_pointG,
            2: self.doneG,
        }

        self.switch_stateR = {
            0: self.correction_rviz,
            1: self.reach_pointR,
            2: self.doneR,
        }

        self.switch_stateP = {
            0: self.correction_puzzlebot,
            1: self.reach_pointP,
            2: self.doneP,
        }

        self.msg_to_publish = Twist()
        self.msg_to_publish_rviz = Twist()
        self.msg_to_publish_puzzlebot = Twist()
        
        # Publicador y suscriptor
        self.pub = rospy.Publisher("/puzzlebot_1/base_controller/cmd_vel", Twist, queue_size=10)
        self.pub_rviz = rospy.Publisher("/cmd_vel_RVIZ", Twist, queue_size=10)
        self.pub_puzzlebot = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        
        self.goal_gazebo_pub = rospy.Publisher("/goal_gazebo", Point, queue_size=10)
        self.goal_rviz_pub = rospy.Publisher("/goal_rviz", Point, queue_size=10)
        self.goal_puzzlebot_pub = rospy.Publisher("/goal_puzzlebot", Point, queue_size=10)

        self.goal_gazebo_pub.publish(self.local_goal_G)
        self.goal_rviz_pub.publish(self.local_goal_R)
        self.goal_puzzlebot_pub.publish(self.local_goal_P)
                
        self.sub_gazebo = rospy.Subscriber("/odom_gazebo", Odometry, self.calc_pos_gazebo)
        self.sub_rviz = rospy.Subscriber("/odom_rviz", Odometry, self.calc_pos_rviz)
        self.sub_puzzlebot = rospy.Subscriber("/odom_puzzlebot", Odometry, self.calc_pos_puzzlebot)

        self.rate = rospy.Rate(50)
        
    def wrap_to_pi(self, theta):
        result = np.fmod(theta + np.pi, 2 * np.pi)
        if isinstance(theta, np.ndarray):
            result[result < 0] += 2 * np.pi
        elif result < 0: 
            result += 2 * np.pi
        return result - np.pi

    def set_Trajectory(self, goal: Point):
        self.local_goal_R = goal
        self.local_goal_G = goal
        self.local_goal_P = goal
    
    def doneG(self):
        self.msg_to_publish.linear.x = 0
        self.msg_to_publish.angular.z = 0
        self.pub.publish(self.msg_to_publish)

    def doneR(self):
        self.msg_to_publish_rviz.linear.x = 0
        self.msg_to_publish_rviz.angular.z = 0
        self.pub_rviz.publish(self.msg_to_publish_rviz)

    def doneP(self):
        self.msg_to_publish_puzzlebot.linear.x = 0
        self.msg_to_publish_puzzlebot.angular.z = 0
        self.pub_puzzlebot.publish(self.msg_to_publish_puzzlebot)
       
    #Goal point changing functions for each Robot System
    def reach_pointG(self):
        if self.index_G == self.n_goals-1:
            self.change_stateG(2)
        else:    
            self.index_G +=1 #Next Point
            self.goal_gazebo_pub.publish(self.local_goal_G)
            self.index_G = self.index_G % self.n_goals
            self.local_goal_G = self.goals[self.index_G]           
            self.change_stateG(0)
    
    def reach_pointR(self):
        if self.index_R == self.n_goals-1:
            self.change_stateR(2)
        else:    
            self.index_R +=1 #Next Point
            self.goal_rviz_pub.publish(self.local_goal_R)
            self.index_R = self.index_R % self.n_goals
            self.local_goal_R = self.goals[self.index_R]           
            self.change_stateR(0)

    def reach_pointP(self):
        if self.index_P == self.n_goals-1:
            self.change_stateP(2)
        else:    
            self.index_P +=1 #Next Point
            self.goal_puzzlebot_pub.publish(self.local_goal_P)
            self.index_P = self.index_P % self.n_goals
            self.local_goal_P = self.goals[self.index_P]           
            self.change_stateP(0)

    #State changing functions for each Robot System       
    def change_stateG(self, n):
        self.state_G = n
    def change_stateR(self, n):
        self.state_R = n
    def change_stateP(self, n):
        self.state_P = n

    def correction_gazebo(self):
        error_x = self.local_goal_G.x - self.current_pos_gazebo.x
        error_y = self.local_goal_G.y - self.current_pos_gazebo.y
        desired_yaw = math.atan2(error_y, error_x)
        #Errores Proporcionales
        self.ang_error = self.wrap_to_pi(desired_yaw - self.yaw_gazebo)
        self.ang_error = self.ang_error if math.fabs(self.ang_error) > 0.020 else 0
        self.dist_error = math.sqrt(math.pow((error_y), 2) + math.pow((error_x), 2))
        #Errores Integrales
        self.error_int_ang += self.ang_error * self.dt
        self.error_int_dist += self.dist_error * self.dt
        #Errores derivativos
        error_dev_ang = self.ang_error - self.error_prev_ang
        error_dev_dist = self.dist_error - self.error_prev_dist
        #Errores anteriores para derivacion
        self.error_prev_ang = self.ang_error
        self.error_prev_dist = self.dist_error

        #Controladores PID
        ang_control = (self.kp_ang * self.ang_error) + (self.ki_ang * self.error_int_ang) + (self.kd_ang * error_dev_ang)
        dist_control = (self.kp_dist * self.dist_error) + (self.ki_dist * self.error_int_dist) + (self.kd_dist* error_dev_dist)
        
        if math.fabs(ang_control) < self.min_angular_speed:
            ang_control = self.min_angular_speed if ang_control > 0 else -self.min_angular_speed

        #significa que tiene que seguir rotando hasta llegar al angulo deseado
        if math.fabs(self.ang_error) > 0.020:
            self.msg_to_publish.linear.x = 0
            self.msg_to_publish.angular.z = ang_control 
            self.pub.publish(self.msg_to_publish)
        else:
        #Significa que se oriento completamente al angulo deseado del Goal
            self.ang_error = 0.0
            if self.dist_error > self.threshold_distance:
                if math.fabs(dist_control) < self.min_linear_speed:
                    dist_control = self.min_linear_speed if dist_control > 0 else -self.min_linear_speed
                self.msg_to_publish.linear.x = dist_control
                self.msg_to_publish.angular.z = 0
                self.pub.publish(self.msg_to_publish)
            else:
                self.dist_error = 0.0
                self.error_int_ang = 0.0
                self.error_int_dist = 0.0
                self.change_stateG(1)

    def correction_rviz(self):
        error_x = self.local_goal_R.x - self.current_pos.x
        error_y = self.local_goal_R.y - self.current_pos.y
        desired_yaw = math.atan2(error_y, error_x)
        #Errores Proporcionales
        self.ang_error_rviz = self.wrap_to_pi(desired_yaw - self.yaw_rviz)
        self.ang_error_rviz = self.ang_error_rviz if math.fabs(self.ang_error_rviz) > 0.001 else 0
        self.dist_error_rviz = math.sqrt(math.pow((error_y), 2) + math.pow((error_x), 2))
        #Errores Integrales
        self.error_int_ang_rviz += self.ang_error_rviz * self.dt
        self.error_int_dist_rviz += self.dist_error_rviz * self.dt
        #Errores derivativos
        error_dev_ang_rviz = self.ang_error_rviz - self.error_prev_ang_rviz
        error_dev_dist_rviz = self.dist_error_rviz - self.error_prev_dist_rviz
        #Errores anteriores para derivacion
        self.error_prev_ang_rviz = self.ang_error_rviz
        self.error_prev_dist_rviz = self.dist_error_rviz

        #Controladores PID
        ang_control_rviz = (self.kp_ang * self.ang_error_rviz) + (self.ki_ang * self.error_int_ang_rviz) + (self.kd_ang * error_dev_ang_rviz)
        dist_control_rviz = (self.kp_dist * self.dist_error_rviz) + (self.ki_dist * self.error_int_dist_rviz) + (self.kd_dist* error_dev_dist_rviz)

        #if math.fabs(ang_control_rviz) < self.min_angular_speed:
            #ang_control_rviz = self.min_angular_speed if ang_control_rviz > 0 else -self.min_angular_speed

        if math.fabs(self.ang_error_rviz) > 0.001:
            self.msg_to_publish_rviz.linear.x = 0
            self.msg_to_publish_rviz.angular.z = ang_control_rviz 
            self.pub_rviz.publish(self.msg_to_publish_rviz)
        else:  
            self.ang_error = 0.0
            if self.dist_error_rviz > self.threshold_distance:
                #if math.fabs(dist_control_rviz) < self.min_linear_speed:
                    #dist_control_rviz = self.min_linear_speed if dist_control_rviz > 0 else -self.min_linear_speed
                self.msg_to_publish_rviz.linear.x = dist_control_rviz
                self.msg_to_publish_rviz.angular.z = 0
                self.pub_rviz.publish(self.msg_to_publish_rviz)
            else:
                self.dist_error_rviz = 0.0
                self.error_int_ang_rviz = 0.0
                self.error_int_dist_rviz = 0.0
                self.change_stateR(1)
        


    def correction_puzzlebot(self):
        error_x = self.local_goal_P.x - self.current_pos_puzzlebot.x
        error_y = self.local_goal_P.y - self.current_pos_puzzlebot.y
        desired_yaw = math.atan2(error_y, error_x)
        
        ref_ang_puzzlebot = np.arctan2(error_y, error_x)
        
        self.ang_error_puzzlebot = self.wrap_to_pi(ref_ang_puzzlebot - self.yaw_puzzlebot)                 
        self.error_int_ang_puzzlebot += self.ang_error_puzzlebot* self.dt
        error_dev_ang = self.ang_error_puzzlebot - self.error_prev_ang_puzzlebot
        self.error_prev_ang_puzzlebot = self.ang_error_puzzlebot
        ang_control_puzzlebot = (self.kp_ang * self.ang_error_puzzlebot) + (self.ki_ang * self.error_int_ang_puzzlebot) + (self.kd_ang * error_dev_ang)
        
        if ang_control_puzzlebot > 0:
            ang_control_puzzlebot = max(self.min_angular_speed, ang_control_puzzlebot)
        else:
            ang_control_puzzlebot = min(-self.min_angular_speed, ang_control_puzzlebot)
    
        
        if math.fabs(self.ang_error_puzzlebot) > 0.015 and math.fabs(self.ang_error_puzzlebot) >0.0:
            self.msg_to_publish_puzzlebot.angular.z = ang_control_puzzlebot if self.ang_error_puzzlebot> 0 else -ang_control_puzzlebot
            self.msg_to_publish_puzzlebot.linear.x = 0
            self.pub_puzzlebot.publish(self.msg_to_publish_puzzlebot)
        else:
            self.dist_error_puzzlebot = math.sqrt(math.pow((error_y), 2) + math.pow((error_x), 2))
            self.angle_offset_puzzlebot = self.wrap_to_pi(desired_yaw - self.yaw_puzzlebot)                                     
            self.error_int_dist_puzzlebot = self.dist_error_puzzlebot * self.dt       
            error_dev_dist = self.dist_error_puzzlebot - self.error_prev_dist_puzzlebot
            self.error_prev_dist_puzzlebot = self.dist_error_puzzlebot            
            dist_control_puzzlebot = (self.kp_dist * self.dist_error_puzzlebot) + (self.ki_dist * self.error_int_dist_puzzlebot) + (self.kd_dist* error_dev_dist)
            
            if dist_control_puzzlebot > 0:
                dist_control_puzzlebot = max(self.min_linear_speed, dist_control_puzzlebot)
            else:
                dist_control_puzzlebot = min(-self.min_linear_speed, dist_control_puzzlebot)
        

            if self.dist_error_puzzlebot > self.threshold_distance:
                self.msg_to_publish_puzzlebot.linear.x = dist_control_puzzlebot
                self.msg_to_publish_puzzlebot.angular.z = 0
                self.pub_puzzlebot.publish(self.msg_to_publish_puzzlebot)
            else:
                self.change_stateP(1)
        
            if math.fabs(self.ang_error_puzzlebot) > 0.006:
                self.change_stateP(0)


    def calc_pos_rviz(self, msg):
        self.current_pos = msg.pose.pose.position
        self.yaw_rviz = msg.pose.pose.orientation.z
        
    def calc_pos_gazebo(self, msg):
        self.current_pos_gazebo = msg.pose.pose.position       
        self.yaw_gazebo = msg.pose.pose.orientation.z
        #print_info = " Posicion del robot: %3f   %3f" %(self.current_pos_gazebo.x, self.current_pos_gazebo.y)
        #rospy.loginfo(print_info)

    def calc_pos_puzzlebot(self, msg):
        self.current_pos_puzzlebot= msg.pose.pose.position
        self.yaw_puzzlebot = msg.pose.pose.orientation.z
        
    def run(self):
        while not rospy.is_shutdown():
            self.current_time = rospy.get_time()
            self.dt = (self.current_time - self.previous_time)
            self.previous_time = self.current_time
            print_info = "%3f | %3f |  " %(self.dist_error,self.ang_error)
            rospy.loginfo(print_info)

            self.switch_stateG.get(self.state_G, lambda: rospy.logerr("Unknown State1"))()
            self.switch_stateR.get(self.state_R, lambda: rospy.logerr("Unknown State2"))()
            self.switch_stateP.get(self.state_P, lambda: rospy.logerr("Unknown State3"))()
            
            self.rate.sleep()

if __name__ == '__main__':
    rospy.init_node("controller")
    node = GoToPos()
    node.run()