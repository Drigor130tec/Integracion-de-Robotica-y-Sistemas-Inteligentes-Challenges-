import rospy
import math 
import numpy as np 
from std_msgs.msg import Float32
from nav_msgs.msg import Odometry
from tf.transformations import quaternion_from_euler 

class Localisation:
    def __init__(self):
        #Declaration of the delta Time
        self.dt = rospy.get_param("~dt",0.001)

        #Declaraqtion of Publishers and Subscribers of the Node
        self.wl_sub = rospy.Subscriber("/wl", Float32, self.wl_callback)
        self.wr_sub = rospy.Subscriber("/wr", Float32, self.wr_callback)
        self.odom_pub = rospy.Publisher("/odom", Odometry, queue_size=10)

        #Init Puzzlebot wheel velocities
        self.wl = rospy.get_param("wl", 0.0)
        self.wr = rospy.get_param("wr", 0.0)

        #Wheel Attributes / Physical Robot 
        self.wheel_radio = 0.05
        self.wheel_base = 0.19

        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
    
        #Pose attributes for Localisation
        self.pose = Odometry()
        self.pose.header.stamp = rospy.Time.now()
        self.pose.header.frame_id = "odom"
        self.pose.pose.pose.position.x = rospy.get_param("pose_x", 0.0)
        self.pose.pose.pose.position.y = rospy.get_param("pose_y", 0.0)
        self.pose.pose.pose.position.z = 0.0
        self.pose.pose.pose.orientation.z = rospy.get_param("pose_theta", 0.0)

        self.pose.twist.twist.linear.x = 0.0
        self.pose.twist.twist.angular.z = 0.0     
    
    def calculate_pose(self):
        #Calculation of the linear and angular velkocities
        v = self.wheel_radio * (self.wl + self.wr) / 2.0
        w = self.wheel_radio * (self.wr - self.wl) / self.wheel_base

        #Actualization of position and coordinates
        self.theta += self.wrap_to_pi(self.theta + w * self.dt)
        self.theta = np.arctan2(np.sin(self.theta), np.cos(self.theta))

        self.x += v * math.cos(self.theta) * self.dt
        self.y += v * math.sin(self.theta) * self.dt

        self.pose.header.stamp = rospy.Time.now()
        self.pose.header.frame_id = "odom"
        self.pose.pose.pose.position.x = self.x
        self.pose.pose.pose.position.y = self.y
        quaternion = quaternion_from_euler(0, 0, self.theta)
        self.pose.pose.pose.orientation.x = quaternion[0]
        self.pose.pose.pose.orientation.y = quaternion[1]
        self.pose.pose.pose.orientation.z = quaternion[2]
        self.pose.pose.pose.orientation.w = quaternion[3]

        self.pose.twist.twist.linear.x = v
        self.pose.twist.twist.angular.z = w  

        self.odom_pub.publish(self.pose)

    def wl_callback(self, msg):
        self.wl = msg.data

    def wr_callback(self, msg):
        self.wr = msg.data
    
    def wrap_to_pi(self,theta):
        result = np.fmod((theta + np.pi),(2 * np.pi))
        if(result < 0):
            result += 2 * np.pi
        return result - np.pi
    
if __name__=='__main__':
    #Initialise and Setup node
    rospy.init_node("Localisation")
    LOC = Localisation()

    loop_rate = rospy.Rate(100)
    
    try:
        while not rospy.is_shutdown():
            LOC.calculate_pose()
            loop_rate.sleep()
    
    except rospy.ROSInterruptException:
        pass 