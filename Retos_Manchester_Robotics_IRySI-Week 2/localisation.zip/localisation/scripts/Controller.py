#!/usr/bin/env python3
import rospy
import numpy as np
import math
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry

class SetPoint:
    def __init__(self):
        self.x = []
        self.y = []
        self.index = 0

class ControlNode:
	def __init__(self):
		#self.flag_SetPoint = False
		#self.flag_pricipal = True

		self.SetPoint_sub = rospy.Subscriber('/set_point', SetPoint, self.set_point_callback)
		self.odom_sub = rospy.Subscriber('/odom', Odometry, self.odom_callback)
		self.cmd_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

		#Physical attributes of the Puzzlebot
		self.wheel_base = 0.19
		self.wheel_radio = 0.05

		self.kd_ang = rospy.get_param("angular_kd", 0.1)
		self.kp_ang = rospy.get_param("angular_kp", 0.3)
		self.ki_ang = rospy.get_param("angular_ki", 0.2)

		self.kd_lin = rospy.get_param("linear_kd", 0.1)
		self.kp_lin = rospy.get_param("linear_kp", 0.4)
		self.ki_lin = rospy.get_param("linear_ki", 0.2)

		self.position = 0

		self.last_med_ang = 0.0
		self.last_med_lin = 0.0
		
		self.error_prev_ang = 0.0
		self.error_prev_lin = 0.0

		self.error_acc_ang = 0.0
		self.error_acc_lin = 0.0

		self.error_ang = 0.0
		self.error_lin = 0.0

		self.actual_x = 0
		self.goal_x = 0
		self.actual_y = 0
		self.goal_y = 0

		#Pose attributes for Localisation
		self.pose_x = rospy.get_param("pose_x", 0.0)
		self.pose_y = rospy.get_param("pose_y", 0.0)
		self.pose_z = 0.0
		self.pose_theta = rospy.get_param("pose_theta", 0.0)

		#Time meditions
		self.current_time = 0.0
		self.previous_time = 0.0
		self.dt = self.current_time - self.previous_time

		#Parameter info for Publishing
		self.msg = Twist()
		self.msg.linear.x = 0
		self.msg.linear.y = 0
		self.msg.linear.z = 0
		self.msg.angular.x = 0
		self.msg.angular.y = 0
		self.msg.angular.z = 0


	def set_point_callback(self, msg):
		self.goal_x = msg.x
		self.goal_y = msg.y
		self.position = msg.index
		self.flag_set_point = True

	def odom_callback(self, msg):
		self.pose_x = msg.pose.pose.position.x
		self.pose_y = msg.pose.pose.position.y
		self.pose_theta = msg.pose.pose.orientation.z

	def wrap_to_pi(self, theta):
		result=np.fmod((theta+ np.pi),(2*np.pi))
		if(result<0):
			result += 2 * np.pi
		return result - np.pi

	def controller(self):
		error_ang = 0.0
		error_lin = 0.0

		self.error_prev_ang = error_ang
		self.error_prev_lin = error_lin   

		error_ang = self.wrap_to_pi((math.atan2(float(self.goal_y[self.position]), float(self.goal_x[self.position]))) - self.pose_theta)
		error_lin =np.sqrt(np.square(float(self.goal_x[self.position]) - self.pose_x) + np.square(float(self.goal_y[self.position]) - self.pose_y))

		self.error_acc_ang += error_ang * self.dt
		self.error_acc_lin += error_lin * self.dt

		#Components of PID controller
		accion_proporcional_ang = self.kp_ang * error_ang
		accion_proporcional_lin = self.kp_lin * error_lin

		accion_integral_ang = self.ki_ang * self.error_acc_ang
		accion_integral_lin = self.ki_lin * self.error_acc_lin
		
		accion_derivativa_ang = self.kd_ang * self.error_acc_ang
		accion_derivativa_lin = self.kd_lin * self.error_acc_lin

		control_ang= accion_proporcional_ang + accion_integral_ang + accion_derivativa_ang  
		control_lin= accion_proporcional_lin + accion_integral_lin + accion_derivativa_lin

		vel_ang = self.last_med_ang + ((control_ang - self.last_med_ang))
		vel_lin = self.last_med_lin + ((control_lin - self.last_med_lin))

		self.last_med_ang = vel_ang
		self.last_med_lin = vel_lin

		self.msg.angular.z = vel_ang

		#Measurements for error correction
		#Below the threshold its considered error free
		if error_ang < 0.02:
			self.msg.linear.x = vel_lin

		if error_lin < 0.05 :
			self.msg.linear.x = 0.0
			self.msg.angular.z = 0.0
			self.position += 1
			self.pose_x=0.0
			self.pose_y=0.0

if __name__=='__main__':

	rospy.init_node("ControlNode") 
	CN = ControlNode()
	
	try:
		previous_time = rospy.get_time()  # Inicializar previous_time fuera del bucle
		while not rospy.is_shutdown():
			current_time = rospy.get_time()  # Obtener el tiempo actual en cada iteración
			loop_rate = rospy.Rate(10)

			CN.dt = current_time - previous_time  # Calcular dt en cada iteración
			previous_time = current_time  # Actualizar previous_time para la próxima iteración

			CN.controller()

			CN.cmd_pub.publish(CN.msg)
			loop_rate.sleep()

	except rospy.ROSInterruptException:
		pass
