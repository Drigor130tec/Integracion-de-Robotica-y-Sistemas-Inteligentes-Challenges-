#!/usr/bin/env python3
import rospy
import math
import tf2_ros
from geometry_msgs.msg import TransformStamped

from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState
from geometry_msgs.msg import TransformStamped
from geometry_msgs.msg import Quaternion

#Declare Variables to be used

class RobotStatePublisher: 
    def __init__(self):

        self.pose_x = rospy.get_param("pose_x", 0.0)
        self.pose_y = rospy.get_param("pose_y", 0.0)
        self.pose_z = rospy.get_param("pose_z", 0.0)
        self.pose_theta = rospy.get_param("pose_theta", 0.0)

        self.broadcaster = tf2_ros.TransformBroadcaster()

        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.odom_callback)
        self.pose_pub = rospy.Publisher("/tf", TransformStamped, queue_size=10)
        self.joint_pub = rospy.Publisher("/joint_states", JointState, queue_size=10)
        self.init_joints()

    def init_joints(self):
        self.contJoints = JointState()
        self.contJoints2 = JointState()
        
        self.contJoints.header.frame_id = "wr_link"
        self.contJoints.header.stamp = rospy.Time.now()
        self.contJoints.name.extend(["rightWheel"])
        
        self.contJoints.position.extend ([0.0])
        self.contJoints.velocity.extend ([0.0])
        self.contJoints.effort.extend ([0.0])       

        self.contJoints2.header.frame_id = "wl_link"
        self.contJoints2.header.stamp = rospy.Time.now()
        self.contJoints2.name.extend(["leftWheel"])
        
        self.contJoints2.position.extend ([0.0])
        self.contJoints2.velocity.extend ([0.0])
        self.contJoints2.effort.extend ([0.0])   

    def odom_callback(self, msg):
        self.pose_x = msg.pose.pose.position.x
        self.pose_y = msg.pose.pose.position.y
        self.pose_z = msg.pose.pose.position.z
        self.pose_theta = msg.pose.pose.orientation.z

        quaternion = self.transform(0.0, 0.0, self.pose_theta)
    
        self.broadcast_transform(self.pose_x, self.pose_y, self.pose_z, quaternion)             
    
    def transform(self, roll, pitch, yaw):
        quaternion = Quaternion()

        ci = math.cos(roll / 2.0)
        si = math.sin(roll / 2.0)
        cj = math.cos(pitch / 2.0)
        sj = math.sin(pitch / 2.0)
        ck = math.cos(yaw / 2.0)
        sk = math.sin(yaw / 2.0)
        cc = ci * ck
        cs = ci * sk
        sc = si * ck
        ss = si * sk

        quaternion.w = cj * sc - sj * cs
        quaternion.x = cj * ss + sj * cc
        quaternion.y = cj * cs - sj * sc
        quaternion.z = cj * cc + sj * ss
        return quaternion
    
    def broadcast_transform(self, x, y, z, quaternion):
        #br = tf2_ros.TransformBroadcaster()
        t = TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "odom"
        t.child_frame_id = "base_link"
        t.transform.translation.x = x
        t.transform.translation.y = y
        t.transform.translation.z = z
        t.transform.rotation = quaternion

        self.broadcaster.sendTransform([t])

if __name__ =='__main__':
    #Initialise and Setup node
    rospy.init_node("RobotStatePublisher")
    RSP= RobotStatePublisher()
    loop_rate = rospy.Rate(rospy.get_param("~node_rate",100))    
    
    try:
        while not rospy.is_shutdown():
            RSP.joint_pub.publish(RSP.contJoints)
            #RSP.broadcaster.sendTransform(RSP.t)
            loop_rate.sleep()
    
    except rospy.ROSInterruptException:
        pass