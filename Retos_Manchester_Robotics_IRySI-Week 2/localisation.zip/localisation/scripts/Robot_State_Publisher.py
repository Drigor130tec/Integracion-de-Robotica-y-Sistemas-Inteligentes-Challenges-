#!/usr/bin/env python3
import rospy
import tf2_ros
import numpy as np
import math

from geometry_msgs.msg import TransformStamped, Quaternion
from tf.transformations import quaternion_from_euler 
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState

class RobotStatePublisher: 
    def __init__(self):

        #Robot's Position
        self.pose_x = rospy.get_param("pose_x", 0.0)
        self.pose_y = rospy.get_param("pose_y", 0.0)
        self.pose_z = rospy.get_param("pose_z", 0.0)
        self.pose_theta = rospy.get_param("pose_theta", 0.0)

        #Roboty's Velocities
        self.v = rospy.get_param("vel_lin", 0.0)
        self.w = rospy.get_param("vel_ang", 0.0)

        self.broadcaster = tf2_ros.TransformBroadcaster()

        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.odom_callback)
        
        self.joint_pub = rospy.Publisher("/joint_states", JointState, queue_size=10)

    def odom_callback(self, msg):
        self.pose_x = msg.pose.pose.position.x
        self.pose_y = msg.pose.pose.position.y
        self.pose_z = msg.pose.pose.position.z
        self.pose_theta = msg.pose.pose.orientation.z

        #Calculation of Linear and Angular velocities using Odomeetry
        linear_velocity_x = msg.twist.twist.linear.x
        linear_velocity_y = msg.twist.twist.linear.y
        angular_velocity = msg.twist.twist.angular.z

        # Velocities using Odometry attributes
        self.v = math.sqrt(linear_velocity_x**2 + linear_velocity_y**2)
        self.w = angular_velocity
     
        quaternion = [0.0, 0.0, 0.0, 0.0]
        quaternion[0] = msg.pose.pose.orientation.x
        quaternion[1] = msg.pose.pose.orientation.y
        quaternion[2] = msg.pose.pose.orientation.z
        quaternion[3] = msg.pose.pose.orientation.w
    
        self.broadcast_transform(self.pose_x, self.pose_y, self.pose_z, quaternion)             

    def broadcast_transform(self, x, y, z, quaternion):

        t = TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "odom"
        t.child_frame_id = "chassis"

        t.transform.translation.x = x
        t.transform.translation.y = y
        t.transform.translation.z = z
        t.transform.rotation.x = quaternion[0]
        t.transform.rotation.y = quaternion[1]
        t.transform.rotation.z = quaternion[2]
        t.transform.rotation.w = quaternion[3]

        self.broadcaster.sendTransform(t)

    def wrap_to_pi(self, theta):
        result=np.fmod((theta+ np.pi),(2*np.pi)) 
        if(result<0):
            result += 2 * np.pi
        return result - np.pi

if __name__ =='__main__':
    #Initialise and Setup node
    rospy.init_node("RobotStatePublisher")
    RobotStatePublisher()
    