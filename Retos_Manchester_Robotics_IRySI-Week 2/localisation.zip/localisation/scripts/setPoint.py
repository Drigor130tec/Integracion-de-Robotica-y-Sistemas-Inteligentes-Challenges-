#!/usr/bin/env python
import rospy
#from localisation.msg import SetPoint

class SetPointNode:
    def __init__(self):
        #self.cmd_pub = rospy.Publisher('/set_point', SetPoint, queue_size=10)  
        self,dummy = 0
        #self.SetPoint = SetPoint()
        #self.SetPoint.list_x = [0]
        #self.SetPoint.list_y = [0]
        #self.SetPoint.index = len(self.SetPoint.x)

if __name__ == '__main__':

    rospy.init_node("SetPointNode")
    #SPN = SetPointNode()
    #SPN.SetPoint.x = [0, 2, 2, 0]
    #SPN.SetPoint.y = [2, 2, 2, 0]
    #SPN.SetPoint.index = len(SPN.SetPoint.x)
    #SPN.cmd_pub.publish(SPN.SetPoint)

    rospy.spin()