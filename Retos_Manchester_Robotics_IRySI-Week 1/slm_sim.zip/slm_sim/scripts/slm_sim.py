#!/usr/bin/env python
import rospy
import logging
import math
import numpy as np
from std_msgs.msg import Float32
from sensor_msgs.msg import JointState

#Declare Variables to be used


class SLM_sim_Node:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    # Setup Variables to be used
        self.k = 0.01
        self.m = 0.75
        self.l = 0.36
        self.g = 9.8
        self.Tau = 0.0
        self.a = self.l/2
        self.j = (4/3)*self.m*self.a*self.a
        
        self.x1 = 0.0 #math.pi/3
        self.x2 = 0.0

        self.joint_pub = rospy.Publisher("/joint_states", JointState, queue_size=10)
        self.vel_pub = rospy.Publisher("/velocity", Float32, queue_size=10)
        self.pos_pub = rospy.Publisher("/position", Float32, queue_size=10)
        self.init_joints()

    def init_joints(self):
        self.contJoints = JointState()

        self.contJoints.header.frame_id = "link1"
        self.contJoints.header.stamp = rospy.Time.now()
        self.contJoints.name.extend(["joint2"])

        self.contJoints.position.extend ([0.0])
        self.contJoints.velocity.extend ([0.0])
        self.contJoints.effort.extend ([0.0])


    def wrap_to_Pi(self,theta):
        result = np.fmod((theta + np.pi),(2 * np.pi))
        if(result < 0):
            result += 2 * np.pi
        return result - np.pi
    

if __name__=='__main__':
    #Initialise and Setup node
    rospy.init_node("SLM_Sim")
    SLM = SLM_sim_Node()

    loop_rate = rospy.Rate(rospy.get_param("~node_rate",100))
    dt = rospy.get_param("~dt",0.01)
    

    print("The SLM sim is Running")
    try:
        while not rospy.is_shutdown():

            SLM.x1 += SLM.x2 * dt
            x2_dot = ((-SLM.m * SLM.g * SLM.a * math.cos(SLM.x1)) / SLM.j ) - ((SLM.k * SLM.x2) / SLM.j) + (SLM.Tau / SLM.j)
            SLM.x2 += x2_dot * dt
            SLM.contJoints.header.stamp = rospy.Time.now()
            t = rospy.Time.now().to_sec()

            SLM.contJoints.position[0] = SLM.wrap_to_Pi(SLM.x1)
            SLM.joint_pub.publish(SLM.contJoints)
            SLM.vel_pub.publish(SLM.x1)
            SLM.pos_pub.publish(SLM.x2)


            loop_rate.sleep()
    
    except rospy.ROSInterruptException:
        pass #Initialise and Setup node
