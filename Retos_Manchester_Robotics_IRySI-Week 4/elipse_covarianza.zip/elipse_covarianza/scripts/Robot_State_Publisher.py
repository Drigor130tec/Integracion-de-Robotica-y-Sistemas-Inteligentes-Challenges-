#!/usr/bin/env python3
import rospy
import tf2_ros
import numpy as np
import math

from std_msgs.msg import Header
from geometry_msgs.msg import TransformStamped, Quaternion, Vector3, Transform, Point, Pose, Twist, PoseWithCovariance, TwistWithCovariance
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState
from std_msgs.msg import String


class RobotStatePublisher: 
    def __init__(self):
        #Robot's Position
        self.time = rospy.Time.now()
       # self.matriz = rospy.Subscriber('matriz_topic', String, self.recibir_matriz)
        self.covariance_matrix = [] 
        self.joint_names = rospy.get_param('~joint_names', ['leftWheel', 'rightWheel'])
        self.effort_constant = [0.0]*len(self.joint_names)
        self.joints_positions = [0.0]*len(self.joint_names)


        self.broadcaster = tf2_ros.TransformBroadcaster()
        self.set_odom_frame()

        #Declaration of Odom message (Ready to Publish)
        self.odom_msg = Odometry(
            header = Header(frame_id = 'odom', 
                            stamp = rospy.Time.now()),
            child_frame_id = '',
            # Pose in inertial frame (world_frame)
            pose = PoseWithCovariance(
                pose = Pose(
                    position = Point(x = 0.0, y = 0.0, z = 0.0),
                    orientation = Quaternion(x = 0.0, y = 0.0, z = self.wrap_to_pi(0.0), w = 1.0)),
                covariance = None
            ),
            # Twist in child frame (puzzlebot)
            twist = TwistWithCovariance(
                twist = Twist(
                    linear = Vector3(x = 0.0, y = 0.0, z = 0.0),
                    angular = Vector3(x = 0.0, y = 0.0, z = 0.0)
                ),
                covariance = None
            )
        )

        #Publisher and Subscriber
        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.odom_callback)      
        self.joint_pub = rospy.Publisher("/joint_states", JointState, queue_size=10)   
        self.is_RVIZ_ok = False
        rospy.Timer(rospy.Duration(1.0/50), self.talk_to_rviz)


    def talk_to_rviz(self, _):
        self.publish_joints()
        self.is_RVIZ_ok = True
        
    #def recibir_matriz(self,mensaje):
     #   # Convertir la cadena de texto del mensaje en una matriz
        
      #  matriz_str = mensaje.data
       # elementos = matriz_str.split(',')
        #self.covariance_matrix  = np.array(elementos, dtype=float).reshape(6, 6) 
        #self.covariance_matrix = self.covariance_matrix.flatten().tolist()
         
        # Procesar la matriz
        #print(self.covariance_matrix)
        
 
    def publish_joints(self,):
        header = Header(frame_id = 'base_link', stamp = rospy.Time.now())
        robot_position_inertial = self.odom_msg.pose.pose.position
        robot_orientation_inertial = self.odom_msg.pose.pose.orientation.z
        
        
 
        
        self.broadcast_transform(robot_position_inertial, robot_orientation_inertial)  
        
        #Position and Velocities of each Joint
        joints_velocities = np.array([self.odom_msg.twist.twist.angular.x, 
                                      self.odom_msg.twist.twist.angular.y])
        
        self.joints_positions = self.wrap_to_pi(self.joints_positions + self.integrate_velocity(joints_velocities))
        
        self.joint_pub.publish(JointState(header=header, 
                                        position=self.joints_positions, 
                                        velocity=joints_velocities, 
                                        name=self.joint_names, 
                                        effort=self.effort_constant))
    def odom_callback(self, msg):
        if self.is_RVIZ_ok:
            self.odom_msg = msg
            self.is_RVIZ_ok = False

    def set_odom_frame(self):
        t = TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "odom"
        t.child_frame_id = "base_link"

        t.transform = Transform(
            translation = Vector3(0.0, 0.0, 0.0),
            rotation = Quaternion(0, 0, 0, 1) 
        )

        self.broadcaster.sendTransform(t)

    def broadcast_transform(self, position, orientation):

        t = TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "odom"
        t.child_frame_id = "base_link"

        t.transform = Transform(
            translation = Vector3(x = position.x,
                                  y = position.y,
                                  z = position.z),
            rotation = Quaternion(*self.quaternion_from_z_rotation(orientation)) 
        )

        self.broadcaster.sendTransform(t)

    def quaternion_from_z_rotation(self, yaw):
        """Convert an euler z-axis rotation (radians) to quaternion form"""
        w = np.cos(yaw / 2)
        z = np.sin(yaw / 2)
        return (0.0, 0.0, z, w)
    
    def wrap_to_pi(self, theta):
        result = np.fmod(theta + np.pi, 2 * np.pi)

        if isinstance(theta, np.ndarray):
            result[result < 0] += 2 * np.pi
        elif result < 0: 
            result += 2 * np.pi
        return result - np.pi
    
    def integrate_velocity(self, wdot):
        return wdot * self.get_dt()
    
    def get_dt(self):
        current_time = rospy.Time.now()
        dt = (current_time - self.time).to_sec()
        self.time = current_time
        return dt

if __name__ == '__main__':
    rospy.init_node("RobotStatePublisher")
    RSP = RobotStatePublisher()

    loop_rate = rospy.Rate(100)  # 10 Hz
  
    try:
        rospy.spin()
            
    except rospy.ROSInterruptException:
        pass
        

