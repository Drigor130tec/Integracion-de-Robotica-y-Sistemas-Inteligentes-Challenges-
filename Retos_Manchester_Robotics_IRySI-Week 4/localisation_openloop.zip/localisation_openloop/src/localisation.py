#!/usr/bin/env python3
import rospy
import message_filters
import math 
import numpy as np 
from std_msgs.msg import Float32, Header
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Vector3, Point, Quaternion, Pose, Twist, PoseWithCovariance, TwistWithCovariance

class Localisation:
    def __init__(self):
        #Declaration of the delta Time
        self.time = rospy.Time.now()

        #Declaration of Publishers and Subscribers of the Node
        wlsub = message_filters.Subscriber('/wl', Float32)
        wrsub = message_filters.Subscriber('/wr', Float32)
        # Synchronizer
        ts = message_filters.ApproximateTimeSynchronizer([wlsub, wrsub], queue_size=10, slop=1.0/50, allow_headerless=True)
        ts.registerCallback(self.w_callback)

        self.odom_pub = rospy.Publisher("/odom", Odometry, queue_size=10)
        self.w_pub = rospy.Publisher("/w_localisation", Float32, queue_size=10)

        #Init Puzzlebot wheel velocities
        self.v = rospy.get_param("v", 0.0)
        self.w = rospy.get_param("w", 0.0)
        self.wl = rospy.get_param("wl", 0.0)
        self.wr = rospy.get_param("wr", 0.0)

        #Wheel Attributes / Physical Robot Attributes
        self.wheel_radio = 0.05
        self.wheel_base = 0.19

        #Pose parameters / Dummy Init
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0

        self.decodematrix = np.array([[self.wheel_radio / 2.0, self.wheel_radio / 2.0], 
                                      [self.wheel_radio / (2*self.wheel_base), - self.wheel_radio / (2*self.wheel_base)]])
    
        self.listening = False   
        rospy.Timer(rospy.Duration(1.0/50), self.odom_publish)

    def system_gradient(self, theta, v, w):
        return np.array([v * np.cos(theta), v * np.sin(theta), w])
    
    #Runge Kutta Method for Differential Ecuations
    def rk4_delta(self, dt, theta, v, w):
        k1 = self.system_gradient(theta, v, w)
        k2 = self.system_gradient(theta + dt*k1[2]/2.0, v, w)
        k3 = self.system_gradient(theta + dt*k2[2]/2.0, v, w)
        k4 = self.system_gradient(theta + dt*k3[2], v, w)
        return dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6.0
    
    def odom_publish(self, _):
        dt = self.get_dt()
        delta = self.rk4_delta(dt, self.theta, self.v, self.w)
        self.x += delta[0]
        self.y += delta[1]
        self.theta += delta[2]

        self.set_odom_msg()
        self.listening = True


    def set_odom_msg(self):
        odom_msg = Odometry(
            header = Header(frame_id = 'odom', 
                            stamp = rospy.Time.now()),
            child_frame_id = '',
            # Pose in inertial frame (world_frame)
            pose = PoseWithCovariance(
                pose = Pose(
                    position = Point(x = self.x, y = self.y, z = 0.0),
                    orientation = Quaternion(x = 0.0, y = 0.0, z = self.wrap_to_pi(self.theta), w = 1.0)),
                covariance = None
            ),
            # Twist in child frame (puzzlebot)
            twist = TwistWithCovariance(
                twist = Twist(
                    linear = Vector3(x = (self.wl * self.wheel_radio), y = (self.wr * self.wheel_radio), z = 0.0),
                    angular = Vector3(x = self.wl, y = self.wr, z = 0.0)
                ),
                covariance = None))

        self.odom_pub.publish(odom_msg)

#SIDE FUNCTIONS
    def w_callback(self, wl, wr):
        if self.listening:
            self.v, self.w = np.dot(self.decodematrix, np.array([wr.data, wl.data]).T).flatten()
            self.w_pub.publish(self.w)
            self.wl = wl.data
            self.wr = wr.data
            self.listening = False
  
    def wrap_to_pi(self,theta):
        result = np.fmod((theta + np.pi),(2 * np.pi))
        if(result < 0):
            result += 2 * np.pi
        return result - np.pi
    
    def get_dt(self):
        current_time = rospy.Time.now()
        dt = (current_time - self.time).to_sec()
        self.time = current_time
        return dt

if __name__=='__main__':
    #Initialise and Setup node
    rospy.init_node("Localisation")
    LOC = Localisation()
    
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        pass 
