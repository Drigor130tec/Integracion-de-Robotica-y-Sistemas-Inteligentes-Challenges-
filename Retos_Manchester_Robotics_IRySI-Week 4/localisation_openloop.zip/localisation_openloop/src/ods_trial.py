#!/usr/bin/env python3
import rospy
import os
from ezodf import newdoc, Sheet
from nav_msgs.msg import Odometry
from std_msgs.msg import  Bool

class odsNode:
    def __init__(self):
        # Inicializa el nodo ROS
        rospy.init_node('ods_writer_node')

        # Suscribe al topic donde se publica la posición del robot
        rospy.Subscriber('/odom_ideal', Odometry, self.odomIdeal_callback)
        rospy.Subscriber('/odom_real', Odometry, self.odomReal_callback)

        # Suscribe al topic para recibir la señal de escritura en el archivo ODS
        rospy.Subscriber('/ods_signal', Bool, self.write_to_ods_callback)

        # Ruta al archivo ODS
        self.ods_file_path = 'data.ods'

        # Ruta al archivo de configuración
        self.config_file_path = 'config.txt'

        # Inicializa la posición del robot
        self.robot_positions = {
            'odom_ideal': (0,0,0),
            'odom_real': (0,0,0)
        }

        # Bandera para indicar si se debe escribir en el archivo ODS
        self.write_to_ods_flag = False

        # Columna actual para la escritura en el archivo ODS
        self.current_column = self.read_config()

    def odomIdeal_callback(self, msg):
        # Guarda la posición del robot desde el mensaje Odometry
        self.robot_positions['odom_ideal'] = (
            msg.pose.pose.position.x,
            msg.pose.pose.position.y,
            msg.pose.pose.orientation.z
        )

    def odomReal_callback(self, msg):
        # Guarda la posición del robot desde el mensaje Odometry
        self.robot_positions['odom_real'] = (
            msg.pose.pose.position.x,
            msg.pose.pose.position.y,
            msg.pose.pose.orientation.z
        )

    def write_to_ods_callback(self, msg):
        # Activa la bandera para escribir en el archivo ODS
        self.write_to_ods_flag = msg.data
        if self.write_to_ods_flag:
            self.write_to_ods()

    def write_to_ods(self):
        # Abre el archivo ODS existente o crea uno nuevo si no existe
        doc = newdoc(doctype='ods', filename=self.ods_file_path)

        # Busca la hoja actual o crea una nueva si no existe
        try:
            sheet = doc.sheets['RobotPosition']
        except KeyError:
            sheet = Sheet(name='RobotPosition')
            doc.sheets.append(sheet)

        # Escribe la posición del robot en la columna actual
        for i, (key, value) in enumerate(self.robot_positions.items()):
            if value is not None:
                for j, coordinate in enumerate(value):
                    sheet[self.current_column + str(i + j + 4)].set_value(coordinate)

        # Incrementa la columna actual para la siguiente ejecución
        self.increment_column()

        # Guarda el documento ODS
        doc.save()

    def increment_column(self):
        # Incrementa la letra de la columna actual ('A' -> 'B', 'B' -> 'C', etc.)
        self.current_column = chr(ord(self.current_column) + 1)
        # Guarda la nueva columna en el archivo de configuración
        with open(self.config_file_path, 'w') as config_file:
            config_file.write(self.current_column)

    def read_config(self):
        # Lee la última columna del archivo de configuración
        if os.path.exists(self.config_file_path):
            with open(self.config_file_path, 'r') as config_file:
                return config_file.read().strip()
        else:
            # Si el archivo no existe, crea uno nuevo y lo inicializa con 'A'
            with open(self.config_file_path, 'w') as config_file:
                config_file.write('A')
            return 'A'


if __name__ == '__main__':
    try:
        ods_writer_node = odsNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
