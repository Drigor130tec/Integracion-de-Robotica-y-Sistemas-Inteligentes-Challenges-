#!/usr/bin/env python3
import rospy
import math
import numpy as np
from geometry_msgs.msg import Twist, PoseStamped, Pose, Point, Quaternion
from std_msgs.msg import Float32

class Real_Sim_Robot:
    def __init__(self):
        #Physical attributes of the Robot 
        self.wheel_radio = 0.05
        self.wheel_base = 0.19

        #Publishers and Subscribers
        self.cmd_sub = rospy.Subscriber('/cmd_vel', Twist, self.cmd_vel_callback)
        self.pose_pub = rospy.Publisher('/pose_ideal', Pose, queue_size=10)
        self.wl_pub = rospy.Publisher('/wl', Float32, queue_size=10)
        self.wr_pub = rospy.Publisher('/wr', Float32, queue_size=10)
        self.w_pub = rospy.Publisher("/w_kinematic", Float32, queue_size=10)

        # Init Robot pose attributes
        self.robot_pose: Pose = Pose(position = Point(x = 0.0, y = 0.0, z = 0.0), orientation = Quaternion(x = 0.0, y = 0.0, z = 0.0, w = 1.0))

        #Init Puzzlebot wheel velocities
        self.wl = rospy.get_param("wl", 0.0)
        self.wr = rospy.get_param("wr", 0.0)

        self.time = rospy.Time.now()

    def cmd_vel_callback(self, msg):
        # Calcular las velocidades angulares de las ruedas izquierda y derecha
        linear_vel = msg.linear.x
        angular_vel = msg.angular.z
        self.w_pub.publish(angular_vel)

        # Control to wheel velocities matrix
        wheel_matrix = np.linalg.inv(np.array([[self.wheel_radio/2.0,                     self.wheel_radio/2.0], 
                                               [self.wheel_radio/(2.0 * self.wheel_base), -self.wheel_radio/(2.0 * self.wheel_base)]]))

        self.wr, self.wl = np.dot(wheel_matrix, np.array([linear_vel, angular_vel]))

        #self.wl = (2.0 * linear_vel - angular_vel * self.wheel_base) / (2*self.wheel_radio)
        #self.wr = (2.0 * linear_vel + angular_vel * self.wheel_base) / (2*self.wheel_radio)

        self.update_Pose(self.get_dt())

    def update_Pose(self, dt):  
        #v = self.wheel_radio * (self.wl + self.wr) / 2.0
        #w = self.wheel_radio * (self.wr - self.wl) / self.wheel_base
        pos = np.array([self.robot_pose.position.x, self.robot_pose.position.y, self.robot_pose.orientation.z])
        pos = pos + self._rk_integration(dt, pos, self.wr, self.wl)

        #Nuevo Sistema no linealizado
        self.robot_pose = Pose(position = Point(x = pos[0], y = pos[1], z = 0.0), 
                      orientation = Quaternion(x = 0.0, y = 0.0, z = self.wrap_to_pi(pos[2]), w = 1.0))

        #sistema no linealizado
        #self.robot_pose.pose.position.x += v * math.cos(self.robot_pose.pose.orientation.z) * dt
        #self.robot_pose.pose.position.y += v * math.sin(self.robot_pose.pose.orientation.z) * dt
        #self.robot_pose.pose.orientation.z += w * dt
        #self.robot_pose.pose.orientation.z = self.wrap_to_pi(self.robot_pose.pose.orientation.z)
        
        #sistema linealizado
        #self.robot_pose.pose.position.x = -v * np.sin(self.robot_pose.pose.orientation.z) * self.robot_pose.pose.position.x * dt
        #self.robot_pose.pose.position.y = v * np.cos(self.robot_pose.pose.orientation.z) * self.robot_pose.pose.position.y * dt      
        #self.robot_pose.pose.orientation.z = self.robot_pose.pose.orientation.z + w * dt
    
    def wrap_to_pi(self, theta):
        result = np.fmod(theta + np.pi, 2 * np.pi)

        if isinstance(theta, np.ndarray):
            result[result < 0] += 2 * np.pi
        elif result < 0: 
            result += 2 * np.pi
        return result - np.pi
    
    def _rk_integration(self, dt, state, wr, wl):
        # Compute RK4 updates
        k1 = self.gradient(state[2], wr, wl)
        k2 = self.gradient(state[2] + dt*k1[2]/2.0, wr, wl)
        k3 = self.gradient(state[2] + dt*k2[2]/2.0, wr, wl)
        k4 = self.gradient(state[2] + dt*k3[2], wr, wl)

        # Update position and orientation using RK4
        return dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6.0
    
    def gradient(self, theta, wr, wl):
        """ Jacobian matrix"""
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        r = self.wheel_radio
        l = self.wheel_base

        #Jacobian Declaration
        J = np.array([[r * cos_theta / 2.0, r * cos_theta / 2.0], 
                      [r * sin_theta / 2.0, r * sin_theta / 2.0], 
                      [r / (2.0 * l), -r / (2.0 * l)]])
        
        return np.dot(J, np.array([wr, wl]))
        
    def publish_robot_state(self):
        self.pose_pub.publish(self.robot_pose)
        self.wl_pub.publish(self.wl)
        self.wr_pub.publish(self.wr)

    def get_dt(self):
        current_time = rospy.Time.now()
        dt = (current_time - self.time).to_sec()
        self.time = current_time
        return dt

if __name__ == '__main__':
    rospy.init_node("Real_Sim_Robot")
    RSR = Real_Sim_Robot()
    loop_rate = rospy.Rate(100)  # 10 Hz
  
    try:
        while not rospy.is_shutdown():
            # Publish Pose and Wheel Velocities
            RSR.publish_robot_state()
            loop_rate.sleep()
            
    except rospy.ROSInterruptException:
        pass
        
