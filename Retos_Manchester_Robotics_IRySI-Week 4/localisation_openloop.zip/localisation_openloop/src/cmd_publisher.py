#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Bool

class CMDNode:
    def __init__(self):
        rospy.init_node('CMDNode', anonymous=True)
        self.twist_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        self.ods_signal_pub = rospy.Publisher('/ods_signal', Bool, queue_size=10)  
        self.rate = rospy.Rate(10)  # Publish Freq - 10 Hz

    def publish_twist(self, duration, velocity):
        twist_msg = Twist()
        twist_msg.linear.x = 0.0
        twist_msg.angular.z = velocity  # Sin velocidad angular

        start_time = rospy.get_rostime()
        while not rospy.is_shutdown():
            current_time = rospy.get_rostime()
            elapsed_time = current_time - start_time

            if elapsed_time.to_sec() >= duration:
                # Si ha pasado la duración, detener el robot
                twist_msg.angular.z = 0.0
                self.twist_pub.publish(twist_msg)
                rospy.loginfo("Deteniendo el robot...")
                self.ods_signal_pub.publish(Bool(True))  # Marcar que el robot se ha detenido

            self.twist_pub.publish(twist_msg)
            rospy.loginfo("Publicando mensaje de velocidad...")
            self.rate.sleep()

    def shutdown_callback(self):
        rospy.loginfo('Cerrando el nodo...')
        # Aquí puedes agregar cualquier limpieza necesaria antes de cerrar el nodo.

if __name__ == '__main__':
    try:
        node = CMDNode()
        duration = 3  # Duración en segundos
        velocity = 0.5 # Velocidad lineal deseada en m/s
        node.publish_twist(duration, velocity)
        rospy.spin()  # Mantener el nodo en ejecución
    except rospy.ROSInterruptException:
        pass
