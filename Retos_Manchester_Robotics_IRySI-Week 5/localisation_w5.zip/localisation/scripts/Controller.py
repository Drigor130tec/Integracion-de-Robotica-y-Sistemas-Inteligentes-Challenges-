#!/usr/bin/env python3
import rospy
import numpy as np
from geometry_msgs.msg import Twist, Point, Vector3, Quaternion, Pose
from nav_msgs.msg import Odometry
from std_msgs.msg import Float32


class ControlNode:
	def __init__(self):	
		self.odom_sub = rospy.Subscriber('/odom_RVIZ', Odometry, self.odom_callback)
		self.cmd_pub = rospy.Publisher('/cmd_vel_RVIZ', Twist, queue_size=10)
		#Publishers for Debugging Goal Coordinate and Error of PID
		self.ref_pub = rospy.Publisher('/ref', Float32, queue_size=10)
		self.error_publisher = rospy.Publisher('/errors', Twist, queue_size=10)

		#Physical attributes of the Puzzlebot
		self.wheel_base = 0.19
		self.wheel_radio = 0.05

		self.kp_lin = rospy.get_param("linear_kp", 0.5)
		self.kp_ang = rospy.get_param("angular_kp", 0.82)

		self.ki_lin = rospy.get_param("linear_ki", 0.008)
		self.ki_ang = rospy.get_param("angular_ki", 0.0002)

		self.kd_lin = rospy.get_param("linear_kd", 0.05)
		self.kd_ang = rospy.get_param("angular_kd", 0.05)
		
		#Integral Errors
		self.error_int_ang = 0.0
		self.error_int_lin = 0.0

		#Last Linear and Angular Errors
		self.error_prev_ang = 0.0
		self.error_prev_lin = 0.0

		# Reference (goal) - Dummy Init
		self.local_goal: Point = None

		# Initial state (inertial frame)
		self.odom_pose : Pose = Pose(position = Point(x = 0.0, y = 0.0, z = 0.0), 
							 		orientation=Quaternion(x=0.0, y=0.0, z=0.0, w=1.0))

	
		#Points of the trajectory
		self.goals = [Point(x = 1.0, y = 0.0, z = 0.0),
               		  Point(x = 1.0, y = 1.0, z = 0.0),
					  Point(x = 0.0, y = 1.0, z = 0.0),
					  Point(x = 0.0, y = 0.0, z = 0.0)]
		
		#Index to iterate through the coordinate list
		self.index = 0
		#Limit of coordinates
		self.n_goals = len(self.goals)
		#Function to create the NextPoint-Trajectory
		self.set_Trajectory(self.goals[self.index])

		self.last_med_ang = 0.0
		self.last_med_lin = 0.0

		#Tolerance for Distance and Angle error
		#Angular tolerance change from degrees to Radians
		self.ang_tolerance : float = 0.009 
		self.lin_tolerance : float = 0.009

		self.error_ang = 0.0
		self.error_lin = 0.0

		#Pose attributes for Localisation
		self.pose_x = rospy.get_param("pose_x", 0.0)
		self.pose_y = rospy.get_param("pose_y", 0.0)
		self.pose_z = 0.0
		self.pose_theta = rospy.get_param("pose_theta", 0.0)

		#Time meditions
		self.time = rospy.Time.now()

		#Parameter info for Publishing
		self.msg = Twist()
		self.msg.linear.x = 0
		self.msg.linear.y = 0
		self.msg.linear.z = 0
		self.msg.angular.x = 0
		self.msg.angular.y = 0
		self.msg.angular.z = 0

		#Timer for running the Publisher
		rospy.Timer(rospy.Duration(1.0/50), self.publish_cmd_vel)

	def get_dt(self):
		current_time = rospy.Time.now()
		dt = (current_time - self.time).to_sec()
		self.time = current_time
		return dt

	#Function that iterates thorugh the list of points and select each as the current goal
	def set_Trajectory(self, goal: Point):
		self.error_int_lin = 0.0
		self.error_int_ang = 0.0

		self.error_prev_lin = 0.0
		self.error_prev_ang = 0.0
		self.local_goal = goal

	def odom_callback(self, msg):
		self.odom_pose = msg.pose.pose

	def wrap_to_pi(self, theta):
		result = np.fmod(theta + np.pi, 2 * np.pi)
		if isinstance(theta, np.ndarray):
			result[result < 0] += 2 * np.pi
		elif result < 0: 
			result += 2 * np.pi
		print(result)
		return result - np.pi

	def compute_error(self):
		error_x = self.local_goal.x - self.odom_pose.position.x
		error_y = self.local_goal.y - self.odom_pose.position.y

        # Distance error
		error_lin = np.sqrt((error_x * error_x) + (error_y * error_y))
		ref_ang = np.arctan2(error_y, error_x)
        # Angular errror		#theta - Markov
		error_ang = self.wrap_to_pi(ref_ang - self.odom_pose.orientation.z)


		#Below the Error threshold is considered error-free
		if np.abs(error_lin) < self.lin_tolerance:
			error_lin = 0.0
		if np.abs(error_ang) < self.ang_tolerance:
			error_ang = 0.0

		#Publish of the goal (Debugging)
		ref = Twist(linear = Vector3(x = self.local_goal.x, y = self.local_goal.y, z = 0.0),
                    angular = Vector3(x = 0.0, y = 0.0, z = ref_ang))     
		#self.ref_pub.publish(ref)

		#Returning of the linear and angular error 
  		#(Difference of the robot in actual position and desired position)
		return error_lin, error_ang
	
	def error_derivation(self, error_lin, error_ang):
		error_dev_lin = error_lin - self.error_prev_lin
		error_dev_ang = error_ang - self.error_prev_ang
		self.error_prev_lin = error_lin
		self.error_prev_ang = error_ang
		return error_dev_lin, error_dev_ang
	
	def publish_cmd_vel(self, _):
		dt = self.get_dt()
		#Components of PID controller
		#Calculation of Proportional Error
		error_lin, error_ang = self.compute_error()
		#Calculation of Integral Error
		self.error_int_lin += error_lin * dt
		self.error_int_ang += error_ang * dt

		#Calculation of Derivative Error
		error_dev_lin, error_dev_ang = self.error_derivation(error_lin, error_ang)

		errorPID = Twist(linear = Vector3(x = error_lin,
									   	  y = self.error_int_lin,
									      z = error_dev_lin),
							
						 angular = Vector3(x = error_ang,
										   y = self.error_int_ang,
										   z = error_dev_ang))
		
		twist_msg = Twist(linear = Vector3(x = 0.0, y = 0.0, z = 0.0),
						  angular = Vector3(x = 0.0, y = 0.0, z = 0.0))
		
		if error_ang != 0.0:	#Not alligned directly to the Goal Coordinate
			twist_msg.angular.z = (self.kp_ang * error_ang) + (self.ki_ang * self.error_int_ang) + (self.kd_ang * error_dev_ang)

		elif error_lin != 0.0:	#If its alligned but it didnt reach the goal yet
			twist_msg.linear.x = (self.kp_lin * error_lin) + (self.ki_lin * self.error_int_lin) + (self.kd_lin * error_dev_lin)

		else:					#Goal Reached
			self.index +=1 #Next Point
			self.index = self.index % self.n_goals
			self.set_Trajectory(self.goals[self.index])

		self.ref_pub.publish(self.index)
		self.cmd_pub.publish(twist_msg)	#Publication of CMD_VEL topic
		#Publication of Error (Debugging)
		self.error_publisher.publish(errorPID)
		#self.lin_tolerance=self.lin_tolerance+self.lin_tolerance

if __name__=='__main__':

	rospy.init_node("ControlNode") 
	CN = ControlNode()
	
	try:
		rospy.loginfo('The controller node FOR RVIZ is Running')
		rospy.spin()
	except rospy.ROSInterruptException:
		pass