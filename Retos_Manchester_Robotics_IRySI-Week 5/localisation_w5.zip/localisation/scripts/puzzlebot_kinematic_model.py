#!/usr/bin/env python3
import rospy
import math
import numpy as np
from geometry_msgs.msg import Twist, Pose, Point, Quaternion
from std_msgs.msg import Float32 , String

class Real_Sim_Robot:
    def __init__(self):
        #Physical attributes of the Robot 
        self.wheel_radio = 0.05
        self.wheel_base = 0.19

        #Publishers and Subscribers
        self.cmd_sub = rospy.Subscriber('/cmd_vel_RVIZ', Twist, self.cmd_vel_callback)
        self.pose_pub = rospy.Publisher('/pose', Pose, queue_size=10)
        self.wl_pub = rospy.Publisher('/wl_RVIZ', Float32, queue_size=10)
        self.wr_pub = rospy.Publisher('/wr_RVIZ', Float32, queue_size=10)
        self.pub = rospy.Publisher('/matriz_topic', String, queue_size=10)

        self.robot_pose: Pose = Pose(position = Point(x = 0.0, y = 0.0, z = 0.0), orientation = Quaternion(x = 0.0, y = 0.0, z = 0.0, w = 1.0))

        #Init Puzzlebot wheel velocities
        self.v = rospy.get_param("v", 0.0)
        self.w = rospy.get_param("w", 0.0)
        
        self.wl = rospy.get_param("wr", 0.0)
        self.wr = rospy.get_param("wl", 0.0)
        
        #matriz covarianza
        self.kl = 0.9795848703
        self.kr = 0.7933479199
        self.covarianza =np.array([[0,0,0],[0,0,0],[0,0,0]])
        
        self.time = rospy.Time.now()
        self.isListening  = False
        #rospy.Timer(rospy.Duration(1.0/50), self.update_Pose)

    def get_dt(self):
        current_time = rospy.Time.now()
        dt = (current_time - self.time).to_sec()
        self.time = current_time
        return dt
    
    def gradient(self, theta, wr, wl):
        """ Jacobian matrix"""
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        r = self.wheel_radio
        l = self.wheel_base

        #Jacobian Declaration
        J_notLin = np.array([[r * cos_theta / 2.0, r * cos_theta / 2.0], 
                            [r * sin_theta / 2.0, r * sin_theta / 2.0], 
                            [r / (2.0 * l), -r / (2.0 * l)]])
        
        J_Lin = np.array([[-r * sin_theta / 2.0, -r * sin_theta / 2.0], 
                           [r * cos_theta / 2.0, r * cos_theta / 2.0], 
                           [r / (2.0 * l), -r / (2.0 * l)]])
        #Not-Linealized Model
        return np.dot(J_notLin, np.array([wr, wl]))
        #Linealized Model
        #return np.dot(J_Lin, np.array([wr, wl]))
    
    def cmd_vel_callback(self, msg):
        if self.isListening:
            self.v = msg.linear.x
            self.w = msg.angular.z
            self.isListening = False

    def wrap_to_pi(self, theta):
        result = np.fmod(theta + np.pi, 2 * np.pi)

        if isinstance(theta, np.ndarray):
            result[result < 0] += 2 * np.pi
        elif result < 0: 
            result += 2 * np.pi
        return result - np.pi
    
    def rk_integration(self, dt, state, wr, wl):
        # Compute RK4 updates
        k1 = self.gradient(state[2], wr, wl)
        k2 = self.gradient(state[2] + dt*k1[2]/2.0, wr, wl)
        k3 = self.gradient(state[2] + dt*k2[2]/2.0, wr, wl)
        k4 = self.gradient(state[2] + dt*k3[2], wr, wl)

        # Update position and orientation using RK4
        return dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6.0

    def update_Pose(self):  
        dt = self.get_dt()

        r = self.wheel_radio
        l = self.wheel_base

        # Control to wheel velocities matrix
        wheel_matrix = np.linalg.inv(np.array([[r/2.0,       r/2.0], 
                                               [r/(2.0 * l), -r/(2.0 * l)]]))

        wr, wl = np.dot(wheel_matrix, np.array([self.v, self.w]))


        pos = np.array([self.robot_pose.position.x, self.robot_pose.position.y, self.robot_pose.orientation.z])
        pos = pos + self.rk_integration(dt, pos, wr, wl)
        
        self.robot_pose = Pose(position = Point(x = pos[0], y = pos[1], z = 0.0), 
                               orientation = Quaternion(x = 0.0, y = 0.0, z = self.wrap_to_pi(pos[2]), w = 1.0))

        self.pose_pub.publish(self.robot_pose)
        self.wl_pub.publish(wl)
        self.wr_pub.publish(wr)
        self.wr = wr
        self.wl = wl
        self.elipse_covarianza(dt)
        

        self.v = 0
        self.w = 0
        self.isListening = True

    def elipse_covarianza(self, dt):
        #sistema linealizado para elipse de covarianza
        self.x_linealization = -self.v * np.sin(self.robot_pose.orientation.z) * self.robot_pose.position.x * dt
        self.y_linealization = self.v * np.cos(self.robot_pose.orientation.z) * self.robot_pose.position.y * dt
              
        self.z_linealization = self.robot_pose.orientation.z + self.w * dt
        #calculamos las matrices que se multiplican
        
        matriz_linealizada= np.array([[1,0,self.x_linealization],
                                      [0,1,self.y_linealization],
                                      [0,0,1]])
        matriz_linealizada_transpuesta=np.transpose(matriz_linealizada)
        
        #calculamos qk
        k=np.array([[self.kr*abs(self.wr),0],
                    [0,self.kl*abs(self.wl)]])
                    
        multiplication=1/2*self.wr*dt
        
        wk= np.dot(np.array([[math.cos(self.robot_pose.orientation.z),math.cos(self.robot_pose.orientation.z)], [math.sin(self.robot_pose.orientation.z),math.sin(self.robot_pose.orientation.z)], 
        [2/self.wl,-2/self.wl]]),multiplication)     
        wk_transpuesta=np.transpose(wk)  
        
        qk1=np.dot(wk,k) 
        qk=np.dot(qk1,wk_transpuesta)
        
        #sacamos el valor final de covarianza
        self.covarianza= np.dot(matriz_linealizada,self.covarianza)
        self.covarianza= np.dot(self.covarianza,matriz_linealizada_transpuesta)+qk     
          
        xx=self.covarianza[0, 0]
        xy=self.covarianza[0, 1]
        x_theta=self.covarianza[0, 2]
        
        yx=self.covarianza[1, 0]
        yy=self.covarianza[1, 1]
        y_theta=self.covarianza[1, 2]
            
        theta_x=self.covarianza[2, 0]
        theta_y=self.covarianza[2, 1]
        theta_theta=self.covarianza[2, 2]
        

        covariance_matrix =np.array([[xx,      xy,    0,      0,    0,   x_theta],
                                     [yx,       yy,    0,      0,    0,   y_theta],
                                     [0,       0,     0,      0,    0,         0],
                                     [0,       0,     0,      0,  0,           0],
                                     [0,       0,     0,      0,   0,    0],
                                     [theta_x, theta_y, 0,      0,    0, theta_theta]])
                                     
        matriz_str = ','.join(str(valor) for fila in covariance_matrix for valor in fila)
        mensaje = String()
        mensaje.data = matriz_str        
        # Publicar el mensaje
        self.pub.publish(mensaje)
        
if __name__ == '__main__':
    rospy.init_node("Real_Sim_Robot")
    RSR = Real_Sim_Robot()
    loop_rate = rospy.Rate(100)  # 10 Hz
  
    try:
        while not rospy.is_shutdown():
            # Publish Pose and Wheel Velocities
            RSR.update_Pose()
            loop_rate.sleep()
            
    except rospy.ROSInterruptException:
        pass