#!/usr/bin/env python3
import rospy
import tf2_ros
import numpy as np
from std_msgs.msg import Header
from geometry_msgs.msg import TransformStamped, Quaternion, Vector3, Transform, Point, Pose, Twist, PoseWithCovariance, TwistWithCovariance
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState


class RobotStatePublisher: 
    def __init__(self):
        #Robot's Position
        self.time = rospy.Time.now()
        self.covariance_matrix = None 
        self.joint_names = rospy.get_param('~joint_names', ['leftWheel', 'rightWheel'])
        self.effort_constant = [0.0]*len(self.joint_names)
        self.joints_positions = [0.0]*len(self.joint_names)
        self.broadcaster = tf2_ros.TransformBroadcaster()

        self.joint_names_Puzzlebot = rospy.get_param('~joint_names2', ['leftWheel2', 'rightWheel2'])
        self.effort_constant_Puzzlebot = [0.0]*len(self.joint_names_Puzzlebot)
        self.joints_positions_Puzzlebot = [0.0]*len(self.joint_names_Puzzlebot)
        self.broadcasterPuzzlebot = tf2_ros.TransformBroadcaster()
        self.set_odom_frame()

        #Declaration of Odom message (Ready to Publish) both Robots
        self.odom_msg = Odometry(
            header = Header(frame_id = 'odom', 
                            stamp = rospy.Time.now()),
            child_frame_id = '',
            # Pose in inertial frame (world_frame)
            pose = PoseWithCovariance(
                pose = Pose(
                    position = Point(x = 0.0, y = 0.0, z = 0.0),
                    orientation = Quaternion(x = 0.0, y = 0.0, z = self.wrap_to_pi(0.0), w = 1.0)),
                covariance = None
            ),
            # Twist in child frame (puzzlebot)
            twist = TwistWithCovariance(
                twist = Twist(
                    linear = Vector3(x = 0.0, y = 0.0, z = 0.0),
                    angular = Vector3(x = 0.0, y = 0.0, z = 0.0)
                ),
                covariance = None
            )
        )
        self.odom_puzzlebot_msg = Odometry(
            header = Header(frame_id = 'odom', 
                            stamp = rospy.Time.now()),
            child_frame_id = '',
            # Pose in inertial frame (world_frame)
            pose = PoseWithCovariance(
                pose = Pose(
                    position = Point(x = 0.0, y = 0.0, z = 0.0),
                    orientation = Quaternion(x = 0.0, y = 0.0, z = self.wrap_to_pi(0.0), w = 1.0)),
                covariance = None
            ),
            # Twist in child frame (puzzlebot)
            twist = TwistWithCovariance(
                twist = Twist(
                    linear = Vector3(x = 0.0, y = 0.0, z = 0.0),
                    angular = Vector3(x = 0.0, y = 0.0, z = 0.0)
                ),
                covariance = None
            )
        )

        #Publisher and Subscriber
        self.odom_sub = rospy.Subscriber('/odom_RVIZ', Odometry, self.odom_callback)   
        self.odom_sub_Puzzlebot = rospy.Subscriber('/odom', Odometry, self.odom_Puzzlebot_callback)     

        self.joint_pub = rospy.Publisher("/joint_states", JointState, queue_size=10)
        self.joint_pub_Puzzlebot = rospy.Publisher("/joint_states2", JointState, queue_size=10)

        self.is_RVIZ_ok = False
        self.is_RVIZ2_ok = False
        rospy.Timer(rospy.Duration(1.0/50), self.talk_to_rviz)


    def talk_to_rviz(self, _):
        self.publish_joints()
        self.is_RVIZ_ok = True
        self.is_RVIZ2_ok = True

    def publish_joints(self,):
        header = Header(frame_id = 'base_link', stamp = rospy.Time.now())
        header2 = Header(frame_id = 'base_link2', stamp = rospy.Time.now())

        robot_position_RVIZ = self.odom_msg.pose.pose.position
        robot_orientation_RVIZ= self.odom_msg.pose.pose.orientation.z

        robot_position_Puzzlebot = self.odom_puzzlebot_msg.pose.pose.position
        robot_orientation_Puzzlebot = self.odom_puzzlebot_msg.pose.pose.orientation.z
        
        self.broadcast_transform(robot_position_RVIZ, robot_orientation_RVIZ)  
        self.broadcast_transform_Puzzlebot(robot_position_Puzzlebot, robot_orientation_Puzzlebot)  
        
        #Position and Velocities of each Joint
        joints_velocities = np.array([self.odom_msg.twist.twist.angular.x, 
                                      self.odom_msg.twist.twist.angular.y])
        
        joints_velocities_Puzzlebot = np.array([self.odom_puzzlebot_msg.twist.twist.angular.x, 
                                                self.odom_puzzlebot_msg.twist.twist.angular.y])
        
        self.joints_positions = self.wrap_to_pi(self.joints_positions + self.integrate_velocity(joints_velocities))
        self.joints_positions_Puzzlebot = self.wrap_to_pi(self.joints_positions_Puzzlebot + self.integrate_velocity(joints_velocities_Puzzlebot))
        
        self.joint_pub.publish(JointState(header=header, 
                                        position=self.joints_positions, 
                                        velocity=joints_velocities, 
                                        name=self.joint_names, 
                                        effort=self.effort_constant))
        
        self.joint_pub_Puzzlebot.publish(JointState(header=header2, 
                                                    position=self.joints_positions_Puzzlebot, 
                                                    velocity=joints_velocities_Puzzlebot, 
                                                    name=self.joint_names_Puzzlebot, 
                                                    effort=self.effort_constant_Puzzlebot))
    def odom_callback(self, msg):
        if self.is_RVIZ_ok:
            self.odom_msg = msg
            self.is_RVIZ_ok = False

    def odom_Puzzlebot_callback(self, msg):
        if self.is_RVIZ2_ok:
            self.odom_puzzlebot_msg = msg
            self.is_RVIZ2_ok = False

    def set_odom_frame(self):
        t = TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "odom"
        t.child_frame_id = "base_link"

        t.transform = Transform(
            translation = Vector3(0.0, 0.0, 0.0),
            rotation = Quaternion(0, 0, 0, 1) 
        )

        t2 = TransformStamped()
        t2.header.stamp = rospy.Time.now()
        t2.header.frame_id = "odom"
        t2.child_frame_id = "base_link2"

        t2.transform = Transform(
            translation = Vector3(0.0, 0.0, 0.0),
            rotation = Quaternion(0, 0, 0, 1) 
        )

        self.broadcaster.sendTransform(t)
        self.broadcasterPuzzlebot.sendTransform(t2)

    def broadcast_transform(self, position, orientation):

        t = TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "odom"
        t.child_frame_id = "base_link"

        t.transform = Transform(
            translation = Vector3(x = position.x,
                                  y = position.y,
                                  z = position.z),
            rotation = Quaternion(*self.quaternion_from_z_rotation(orientation)) 
        )

        self.broadcaster.sendTransform(t)


    def broadcast_transform_Puzzlebot(self, position, orientation):
        t = TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "odom"
        t.child_frame_id = "base_link2"

        t.transform = Transform(
            translation = Vector3(x = position.x,
                                  y = position.y,
                                  z = position.z),
            rotation = Quaternion(*self.quaternion_from_z_rotation(orientation)) 
        )

        self.broadcasterPuzzlebot.sendTransform(t)

    def quaternion_from_z_rotation(self, yaw):
        """Convert an euler z-axis rotation (radians) to quaternion form"""
        w = np.cos(yaw / 2)
        z = np.sin(yaw / 2)
        return (0.0, 0.0, z, w)
    
    def wrap_to_pi(self, theta):
        result = np.fmod(theta + np.pi, 2 * np.pi)

        if isinstance(theta, np.ndarray):
            result[result < 0] += 2 * np.pi
        elif result < 0: 
            result += 2 * np.pi
        return result - np.pi
    
    def integrate_velocity(self, wdot):
        return wdot * self.get_dt()
    
    def get_dt(self):
        current_time = rospy.Time.now()
        dt = (current_time - self.time).to_sec()
        self.time = current_time
        return dt

if __name__ == '__main__':
    rospy.init_node("RobotStatePublisher")
    RSP = RobotStatePublisher()

    loop_rate = rospy.Rate(100)  # 10 Hz
  
    try:
        rospy.spin()
            
    except rospy.ROSInterruptException:
        pass