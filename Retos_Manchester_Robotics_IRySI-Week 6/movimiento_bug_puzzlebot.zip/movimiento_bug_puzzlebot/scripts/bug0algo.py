#!/usr/bin/env python

import rospy
import math
from geometry_msgs.msg import Point
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from tf import transformations
#Services require their own type of messages known as Service Messages
#SetBool is predefined ServiceMessage which has a variable called data of type bool
from std_srvs.srv import SetBool

region={
    "eright": 0,
    "right" : 0,
    "center": 0,
    "left" : 0,
    "eleft": 0
    }
srv_wall_follow = None
srv_go_to_pos = None
initial_position = Point()
final_position = Point()
#initial_position.w = rospy.get_param('init_w')

final_position.x = rospy.get_param('dest_pos_x')
final_position.y = rospy.get_param('dest_pos_y')
state = 0
time_delay = 0
time_sec = 0


def change_state(n):
    global state , srv_go_to_pos , srv_wall_follow
    state = n
    rospy.loginfo("Changed to state [{}]".format(n))
    if( n==0 ):
        resp = srv_go_to_pos(True)
        resp = srv_wall_follow(False)
    elif( n==1 ):
        resp = srv_go_to_pos(False)
        resp = srv_wall_follow(True)
    else:
        rospy.loginfo("Invalid State")


def clbk_laser(msg):
    global region
    region = {
        "eright" : min(min(msg.ranges[0:71]) , 2), # Este
        "right" :  min(min(msg.ranges[72:143]) , 2 ), #Noreste
        "center" : min(min(msg.ranges[144:215]) , 2 ), #Norte
        "left" :   min(min(msg.ranges[216:287]) , 2 ), # Noroeste
        "eleft" : min(min(msg.ranges[288:359]) , 2  ) # Oeste
    }



#state 0 = go_to_point
#state 1 = wall_follow
def main():
    global srv_wall_follow , srv_go_to_pos , state , region , time_delay , time_sec
    rospy.init_node("wallfollow_plus_gotopos")
    sub_laser = rospy.Subscriber("/puzzlebot_1/scan" , LaserScan , clbk_laser)

    srv_wall_follow = rospy.ServiceProxy("/serv_wall_follow" , SetBool)
    srv_go_to_pos = rospy.ServiceProxy("/serv_go_to_pos", SetBool)
    
    #We assume that initially there are no obstacle
    change_state(0)

    rate = rospy.Rate(20)
    while not rospy.is_shutdown():
        print(state)
        if (state == 0):
            
            if (region["center"] < 0.5 and region["center"] > 0.15):
                time_delay=0
                time_sec = 0
                change_state(1)
        if (state == 1):
            
            if(region["center"] > 0.5  and region["eright"] > 0.6 and region["eleft"] > 0.6):
                change_state(0)
        time_delay = time_delay+1
        if time_delay == 20 :
            time_sec = time_sec+1
            time_delay=0
        rate.sleep()


if __name__ == "__main__" :
    main()
