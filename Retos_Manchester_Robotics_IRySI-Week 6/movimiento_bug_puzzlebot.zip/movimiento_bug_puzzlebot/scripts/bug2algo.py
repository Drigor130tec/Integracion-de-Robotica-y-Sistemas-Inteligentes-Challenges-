#!/usr/bin/env python

import rospy
import math
import numpy as np
import message_filters
from geometry_msgs.msg import Point
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from tf import transformations
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32, Header, String
from geometry_msgs.msg import Pose2D

#Services require their own type of messages known as Service Messages
#SetBool is predefined ServiceMessage which has a variable called data of type bool
from std_srvs.srv import SetBool

region={
    "eright": 0,
    "right" : 0,
    "center": 0,
    "left" : 0,
    "eleft": 0
    }
srv_wall_follow = None
srv_go_to_pos = None
initial_position = Point()
final_position = Point()
current_pos = Point()
initial_position.x = rospy.get_param('init_x')
initial_position.y = rospy.get_param('init_y')
final_position.x = rospy.get_param('dest_pos_x')
final_position.y = rospy.get_param('dest_pos_y')
state = 0
time_delay = 0
time_sec = 0
message = Twist() 
theta = 0.0
error_angle = 0.0

pose = Pose2D()
pose.x = 0.0
pose.y = 0.0
pose.theta = 0.0

l = 0.19
m = 0.05
dt = 0.001

wr = 0.0
wl = 0.0

message = Twist()  

def dist_from_line(x , y):
    global initial_position , final_position
    m = (final_position.y - initial_position.y)/(final_position.x - initial_position.x)
    numerator = math.fabs(y - initial_position.y - m*x + m*initial_position.x)
    denominator = (math.sqrt(1+math.pow(m , 2)))
    dist = numerator/denominator
    return dist

def wr_callback(msg):
    global wr
    wr = msg.data

def wl_callback(msg):
    global wl
    wl = msg.data
        
    

def change_state(n):
    global state , srv_go_to_pos , srv_wall_follow ,mensaje , erro
    state = n
    rospy.loginfo("Changed to state [{}]".format(n))
    if( n==0 ):
        resp = srv_go_to_pos(True)
        resp = srv_wall_follow(False)
    elif( n==1 ):
        resp = srv_go_to_pos(False)
        resp = srv_wall_follow(True)
    elif( n==2):
        resp = srv_go_to_pos(True)
        resp = srv_wall_follow(False)
    else:
        rospy.loginfo("Invalid State")


def wrap_to_pi( theta):
    result = np.fmod(theta + np.pi, 2 * np.pi)
    if isinstance(theta, np.ndarray):
        result[result < 0] += 2 * np.pi
    elif result < 0: 
        result += 2 * np.pi
    print(result)
    return result - np.pi


def clbk_laser(msg):
    global region
    region = {
        
        "eright" : min(min(msg.ranges[0:71]) , 2 ),
        "right" :  min(min(msg.ranges[72:143]) , 2 ),
        "center" : min(min(msg.ranges[144:215]) , 2 ),
        "left" :   min(min(msg.ranges[216:287]) , 2 ),
        "eleft" : min(min(msg.ranges[288:359]) , 2 )
    }

def clbk_odom(msg):
    global current_pos , yawz
    current_pos = msg.pose.pose.position

#state 0 = go_to_point
#state 1 = wall_follow
def main():
    global srv_wall_follow , srv_go_to_pos , state , current_pos , region , time_delay , pub, time_sec , error_angle
    
    rospy.init_node("wallfollow_plus_gotopos")
    sub_laser = rospy.Subscriber("/puzzlebot_1/scan" , LaserScan , clbk_laser)
    sub_odom = rospy.Subscriber("/puzzlebot_1/base_controller/odom" , Odometry, clbk_odom)
    pub= rospy.Publisher("/puzzlebot_1/base_controller/cmd_vel" , Twist , queue_size=1)
    rospy.Subscriber('/puzzlebot_1/wr',Float32,wr_callback)
    rospy.Subscriber('/puzzlebot_1/wl',Float32,wl_callback)
    
    srv_wall_follow = rospy.ServiceProxy("/serv_wall_follow" , SetBool)
    srv_go_to_pos = rospy.ServiceProxy("/serv_go_to_pos", SetBool)
    
    #We assume that initially there are no obstacle
    change_state(0)

    rate = rospy.Rate(20)
    while not rospy.is_shutdown():
        
        dist = dist_from_line(current_pos.x , current_pos.y)
        rospy.loginfo(f"error_ang: {pose.theta}")
        if (state == 0):            
            if (region["center"] < 1.0 and region["center"] > 0.15 ):
                time_delay=0
                time_sec = 0
                change_state(1)
        if (state == 1):
            if (time_sec > 9 and dist < 0.2 ):
                change_state(2)
                
        if (state == 2):
            pose.theta = wrap_to_pi(pose.theta + dt * m * ((wr - wl) / l)) 
            error_angle = wrap_to_pi((final_position.y,final_position.x)-pose.theta)
            rospy.loginfo(f"error_ang: {error_angle}")
            if error_angle > 0.001:
                message.linear.x = 0.0
                message.angular.z = 0.6
                pub.publish(message)
            elif error_angle < 0.001 and error_angle > -0.001 :
                change_state(0)

            
                
        time_delay = time_delay+1
        if time_delay == 20 :
            time_sec = time_sec+1
            time_delay=0
        rate.sleep()


if __name__ == "__main__" :
    main()

