#!/usr/bin/env python

import rospy
import math
from geometry_msgs.msg import Point
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
import numpy as np
import message_filters
from tf import transformations
#Services require their own type of messages known as Service Messages
#SetBool is predefined ServiceMessage which has a variable called data of type bool
from std_srvs.srv import SetBool
from geometry_msgs.msg import Pose2D
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32, Header, String

region={
    "eright": 0,
    "right" : 0,
    "center": 0,
    "left" : 0,
    "eleft": 0
    }

srv_wall_follow = None
srv_go_to_pos = None
initial_position = Point()
final_position = Point()
intermediate_position = Point()
current_pos = Point()
shortest_obst_pos = Point()
desired_position = Point()

desired_position.x = rospy.get_param('dest_pos_x')
desired_position.y = rospy.get_param('dest_pos_y')
desired_position.z = 0
dist_current_to_final = 0
err_dist = 0
time_delay = 0
time_sec = 0
state = 0
err_dist_2 = 0
err_dist_3 = 0

l = 0.19
m = 0.05
dt = 0.001

pose = Pose2D()
pose.x = 0.0
pose.y = 0.0
pose.theta = 0.0

wr = 0.0
wl = 0.0
error_angle = 0.0
def change_state(n):
    global state , srv_go_to_pos , srv_wall_follow
    state = n
    rospy.loginfo("Changed to state [{}]".format(n))
    if( n==0 ):
        resp = srv_go_to_pos(True)
        resp = srv_wall_follow(False)
    elif( n==1 ):
        resp = srv_go_to_pos(False)
        resp = srv_wall_follow(True)
    elif( n==2):
        resp = srv_go_to_pos(False)
        resp = srv_wall_follow(True)
    elif( n==3):
        resp = srv_go_to_pos(True)
        resp = srv_wall_follow(False)
    else:
        rospy.loginfo("Invalid State")

def only_calculate_err_dist(n , m):
    global  err_dist_3
    err_dist_3 = math.sqrt(math.pow(n.y - m.y , 2 ) + math.pow(n.x - m.x  , 2))
    return err_dist_3

def wr_callback(msg):
    global wr
    wr = msg.data

def wl_callback(msg):
    global wl
    wl = msg.data
    

def calculate_err_dist():
    global err_dist , desired_position , current_pos , intermediate_position ,err_dist_2
    err_dist_2 = math.sqrt(math.pow(desired_position.y - current_pos.y , 2 ) + math.pow(desired_position.x - current_pos.x , 2))
    err_dist=err_dist_2
    inter_err_dist = math.sqrt(math.pow(desired_position.y - intermediate_position.y , 2 ) + math.pow(desired_position.x - intermediate_position.x , 2))
    if (err_dist < inter_err_dist):
        intermediate_position = current_pos
    return err_dist

def clbk_laser(msg):
    global region
    region = {
        
        "eright" : min(min(msg.ranges[0:71]) , 2 ),
        "right" :  min(min(msg.ranges[72:143]) , 2 ),
        "center" : min(min(msg.ranges[144:215]) , 2 ),
        "left" :   min(min(msg.ranges[216:287]) , 2 ),
        "eleft" : min(min(msg.ranges[288:359]) , 2 )
    }

def wrap_to_pi( theta):
    result = np.fmod(theta + np.pi, 2 * np.pi)
    if isinstance(theta, np.ndarray):
        result[result < 0] += 2 * np.pi
    elif result < 0: 
        result += 2 * np.pi
    print(result)
    return result - np.pi
    
def clbk_odom(msg):
    global current_pos , yaw
    current_pos = msg.pose.pose.position

#state 0 = go_to_point
#state 1 = wall_follow
def main():
    global srv_wall_follow , srv_go_to_pos , state , current_pos , initial_position , intermediate_position , shortest_obst_pos , time_delay , time_sec , err_dist_3 , error_angle
    rospy.init_node("wallfollow_plus_gotopos")
    sub_laser = rospy.Subscriber("/puzzlebot_1/scan" , LaserScan , clbk_laser)
    sub_odom = rospy.Subscriber("/puzzlebot_1/base_controller/odom" , Odometry, clbk_odom)
    pub= rospy.Publisher("/puzzlebot_1/base_controller/cmd_vel" , Twist , queue_size=1)
    rospy.Subscriber('/puzzlebot_1/wr',Float32,wr_callback)
    rospy.Subscriber('/puzzlebot_1/wl',Float32,wl_callback)

    srv_wall_follow = rospy.ServiceProxy("/serv_wall_follow" , SetBool)
    srv_go_to_pos = rospy.ServiceProxy("/serv_go_to_pos", SetBool)

    #We assume that initially there are no obstacle
    change_state(0)
    count = 1
    rate = rospy.Rate(20)
    while not rospy.is_shutdown():
        calculate_err_dist()
        rospy.loginfo(f"shortest_obst_pos: {shortest_obst_pos}")
        rospy.loginfo(f"Desired position: ({desired_position.x}, {desired_position.y})")
        rospy.loginfo(f"Error distance: {err_dist}")
        rospy.loginfo(f"Error distance3: {err_dist_3}")
    
        if state == 0:
            rospy.loginfo("State 0: Moving towards goal")
            if region["center"] < 0.9 and region["center"] > 0.15:
                rospy.loginfo("Obstacle detected, changing to wall follow")
                time_delay = 0
                time_sec = 0
                initial_position = current_pos
                intermediate_position = current_pos
                if count == 1:
                    shortest_obst_pos = current_pos
                    count += 1
                change_state(1)
    
        if state == 1:
            rospy.loginfo("State 1: Following wall")
            if time_sec > 15 and only_calculate_err_dist(current_pos, shortest_obst_pos) < 0.6:
                rospy.loginfo("Close to shortest obstacle position, changing to go to point")
                shortest_obst_pos = intermediate_position
                change_state(2)
                
        if (state == 2):
            if error_angle > 0.001:
                message.linear.x = 0.0
                message.angular.z = -0.6
                pub.publish(message)
            elif error_angle < 0.001 and error_angle > -0.001 :
                change_state(3)
                
                
        if (state == 3):
            pose.theta = wrap_to_pi(pose.theta + dt * m * ((wr - wl) / l)) 
            error_angle = wrap_to_pi((final_position.y,final_position.x)-pose.theta)
            rospy.loginfo(f"error_ang: {error_angle}")
            if error_angle > 0.001:
                message.linear.x = 0.0
                message.angular.z = -0.6
                pub.publish(message)
            elif error_angle < 0.001 and error_angle > -0.001 :
                change_state(0)


        #rospy.loginfo(f"initial_pose= ({initial_position.x}, {initial_position.y}), current_pose= ({current_pos.x}, {current_pos.y}), shortest_obst_pos= ({shortest_obst_pos.x}, {shortest_obst_pos.y}), intermediate_pose= ({intermediate_position.x}, {intermediate_position.y})")
        rospy.loginfo(f"Time seconds: {time_sec}")    
        time_delay += 1
        if time_delay == 20:
            time_sec += 1
            time_delay = 0
        rate.sleep()


if __name__ == "__main__" :
    main()
